--- Lua bindings for tman.


local tman = {}
local core = require("src.core.core")

---Switch to previous task.
---@return string|nil
function tman.id_prev()
    core.setup(1)
    core.id_prev()

    local curr = core.getcurr()
    local newdir = core.prefix .. "/tasks/" .. curr.env .. "/" .. curr.curr
    return newdir
end

function tman.id_sync()
    core.setup(1)
end

function tman.id_use()
    core.setup(1)
end

function tman.id_list()
    core.setup(1)
    return core.id_list()
end

local res = tman.id_list()
for _, task in pairs(res) do
    print(task.id, task.desc)
end

return tman
