local idlist = require("plugin.idlist.idlist")

local reg = {}
local pgns = {}

---Register plugin and its commands.
function reg.reg()
    table.insert(
        pgns,
        { func = idlist.time, opt = nil, cmd = "list", filter = true }
    )
    table.insert(
        pgns,
        { func = idlist.prio, opt = nil, cmd = "list", filter = true }
    )
end

---Get plugin related to builtin command.
function reg.get(cmd)
    for _, pgn in pairs(pgns) do
        if pgn.cmd == cmd then
            return {
                func = pgn.func,
                opt = pgn.opt,
                cmd = pgn.cmd,
                filter = pgn.filter,
            }
        end
    end
    print("err: not found")
    return {}
end

return reg
