local idlist = {}

function idlist.time()
    return os.date("%h")
end

function idlist.prio()
    return "prio-mid"
end

function idlist.reg()
    return {
        { fmt = "%s", func = idlist.time, type = "filter" },
        { fmt = "%s", func = idlist.prio, type = "filter" },
    }
end

return idlist
