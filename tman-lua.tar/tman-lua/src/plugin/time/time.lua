local time = {}

return time
