local core = require("core.core")
local help = require("aux.help")
local getopt = require("posix.unistd").getopt

---Fix system database.
local function builtin_fix() end

return builtin_fix
