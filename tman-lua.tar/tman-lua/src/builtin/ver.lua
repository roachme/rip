local function builtin_ver()
    print(("%s version %s"):format(program, version))
end

return builtin_ver
