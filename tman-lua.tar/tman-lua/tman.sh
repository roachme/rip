#!/usr/bin/env bash

function tman() {
    OUTPUT="$(_tman "$@")"
    retcode="$?"
    [ "$retcode" -eq 0 ] && cd "$OUTPUT" || echo "$OUTPUT" && return "$retcode"
}
