# Git plugin for tman project


BASEDIR=
ENV=
ID=

DIRNAME=
COMMITPATT=
BRANCHPATT=
REPOS=("wtm master git@gitlab.wimark.com:embedded/wtm.git")
REPOS+=("cpeagent master git@gitlab.wimark.com:embedded/cpeagent.git")

function _repo_clone()
{
    for repo in "${REPOS[@]}"; do
        local name="$(echo "$repo" | cut -f 1 -d ' ')"
        local branch="$(echo "$repo" | cut -f 2 -d ' ')"
        local repourl="$(echo "$repo" | cut -f 3 -d ' ')"
        echo "repo: $name - $branch - $repourl"
    done
    return 0;
}

function _repo_linkrepos()
{
    return 0;
}

function _repo_namebranch()
{
    return 0;
}

function _repo_renamebranch()
{
    return 0;
}


function _repo_init()
{
    mkdir -p "$BASEDIR/pgns/git"
    return $?;
}

function repo_sync()
{
    return 0;
}

function repo_rsync()
{
    return 0;
}

function repo_cat()
{
    return 0;
}

