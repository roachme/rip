

function mytest()
{
    echo "function mytest: $0"
}


