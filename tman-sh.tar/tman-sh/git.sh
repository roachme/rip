#!/usr/bin/env bash

# git:(feature/36676882_Move_wimark-cli_service_to_OpenWrt_package_20240731
PGNGIT_BRANCHPATT="TYPE/ID_DESC_DATE"

function git_ls_repos()
{
    echo "git_ls_repos"
}

function git_create_branch()
{
    local branch="$1"
    git branch "$branch"
}
