# wtm

## Description

`wtm` - local reverse proxy, which forwards traffic between local client and remote broker. Supports `ipsec` and `none` tunnels establishment. In case of active broker becomes unreachable, triggers Discover procedure and tries to find accessible broker again with respect to their priorities. Used in `cpeagent`.

## Documents

* [https://www.strongswan.org/](https://www.strongswan.org/)

## Software Requirements

* gcc 9.5.0

* cppcheck 2.7

* flawfinder 2.0.19

* Ceedling 0.31.1

* CMock 2.5.4

* Unity 2.5.4

* gcov 11.4.0

* gcovr 6.0

* libubox

* libubus

* libuci

* lua 5.1

* Doxygen 1.8.17

* luacheck 1.1.1

* junit2html 30.1.3

* make 4.3

* busted 2.2.0

* ldoc 1.5.0

## Build Process

To build project use:

```bash
make -f MakefileWimark <target>
```

(More information about targets can be found in `MakefileWimark`)
