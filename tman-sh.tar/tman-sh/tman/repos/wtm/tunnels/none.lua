local function none_setup(util, serv, timeout, cb, fail_cb)
    cb(serv.host, serv.port)
end

local function none_cleanup(util, serv, timeout, cb, fail_cb)
    util.debug_print("none down: success")
    cb()
end

return {
    setup = none_setup,
    cleanup = none_cleanup
}
