local os = require "os"
local fs = require "nixio.fs"
local uci = require "uci"
local ubus = require "ubus"

local HEADER = "# Added by WiMark WTM"

local TEMPLATES_DIR = "/usr/lib/lua/wtm/templates/"

local TEMPLATE_IPSEC_PSK = TEMPLATES_DIR .. "/ipsec_psk.conf.template"
local TEMPLATE_STRONGSWAN_PSK = TEMPLATES_DIR .. "/strongswan_psk.conf.template"

local TEMPLATE_IPSEC_PUBKEY = TEMPLATES_DIR .. "/ipsec_pubkey.conf.template"
local TEMPLATE_STRONGSWAN_PUBKEY = TEMPLATES_DIR .. "/strongswan_pubkey.conf.template"

local RUN_DIR = "/var/run/"
local RUN_IPSEC_CONF = RUN_DIR .. "wtm-ipsec.conf"
local RUN_STRONGSWAN_CONF = RUN_DIR .. "wtm-strongswan.conf"
local RUN_IPSEC_SECRETS = "/usr/lib/lua/cpeagent/ipsec/ipsec.secrets"
local RUN_PUBKEY_SECRETS = RUN_DIR .. "wtm-pubkey.secrets"

local CONF_DIR = "/etc/"
local IPSEC_CONF = CONF_DIR .. "ipsec.conf"
local STRONGSWAN_CONF = CONF_DIR .. "strongswan.conf"
local IPSEC_SECRETS = CONF_DIR .. "ipsec.secrets"
local IPSEC_CA = CONF_DIR .. "ipsec.d/cacerts/ca-wtm.pem"

local IPSEC_BROKER_HOST = "10.9.0.1"

local IPSEC_BIN = "/usr/sbin/ipsec"
local IPSEC_CONN = "wimark-wtm"

local IPSEC_TCPING_ATTEMPTS = 3
local IPSEC_TCPING_DELAY = 1000

local IPSEC_IS_READY_ATTEMPTS = 5
local IPSEC_IS_READY_DELAY = 1000

local CRYPTO_SERVICE = "wimark.apcm"

local PUBKEY_SECRETS_FMT = ": RSA %s"

--- Include exteral config in strongswan format
--
-- @param filename Original config file
-- @param config Config file to include
local function include_config(filename, config)
    local line = "include " .. config
    local file = fs.readfile(filename) or ""

    if string.find(file, line, 0, true) then
        return
    end

    file = file .. "\n\n"
    file = file .. HEADER .. "\n"
    file = file .. line .. "\n"

    fs.writefile(filename, file)
end

--- Get cryptographic set paths (CA, certificate and private)
--
-- @return Table with "ca", "cert" and "priv" set on success
-- @return nil On fail (crypto service unavailable)
-- @return nil If secrets are not present
local function crypto_path()
    local conn = ubus.connect()
    local path = conn:call(CRYPTO_SERVICE, "crypto_path", {}) or {}

    local ca_pr = path.ca and fs.stat(path.ca)
    local cert_pr = path.cert and fs.stat(path.cert)
    local priv_pr = path.priv and fs.stat(path.priv)

    if not ca_pr or not cert_pr or not priv_pr then
        return nil
    end

    return path
end

--- Check if CA certificate loaded by ipsec
--
-- @return true If CA is loaded
-- @return false If CA is not loaded
local function ipsec_check_ca()
    local ipsec_cmd = io.popen("ipsec listcacerts", "r")
    local ipsec_certs = ipsec_cmd:read("*a") or ""
    ipsec_cmd:close()

    if string.find(ipsec_certs, "X.509 CA Certificates", 0, true) then
        return true
    end

    return false
end

--- Check if encryption should be enabled or not (only for PSK)
--
-- @return true if ipsec encryption should be enabled
-- @return false if ipsec encryption should be disabled
local function check_encryption_enabled()
    local cursor = uci.cursor()
    local disable_enc = cursor:get("wimark", "broker", "ipsec_disable_encryption")
    return not disable_enc or disable_enc ~= "1"
end

--- Prepare ipsec configuration for PSK authentication
--
-- @param id Machine identifier for connection
-- @param host Ipsec server
-- @return table which contains string configuration for ipsec.conf
--         and strongswan.conf (to be written to config file)
local function ipsec_prepare_psk_config(id, host)
    local ipsec_conf_format = HEADER .. "\n" .. (fs.readfile(TEMPLATE_IPSEC_PSK) or "")
    local strongswan_conf_format = HEADER .. "\n" .. (fs.readfile(TEMPLATE_STRONGSWAN_PSK) or "")

    -- Include PSK
    include_config(IPSEC_SECRETS, RUN_IPSEC_SECRETS)

    -- Check encryption
    local esp = "aes256-sha1-modp1024"
    if not check_encryption_enabled() then
        esp = "null-sha1"
    end

    return {
        ipsec = ipsec_conf_format:format(id, esp, host),
        strongswan = strongswan_conf_format:format()
    }
end

--- Prepare ipsec configuration for PUBKEY authentication
--
-- @param id Machine identifier for connection
-- @param host Ipsec server
-- @param crypto Cryptographic path table (ca, cert and priv), @see crypto_path
-- @return table which contains string configuration for ipsec.conf
--         and strongswan.conf (to be written to config file)
local function ipsec_prepare_pubkey_config(id, host, crypto)
    local ipsec_conf_format = HEADER .. "\n" .. (fs.readfile(TEMPLATE_IPSEC_PUBKEY) or "")
    local strongswan_conf_format = HEADER .. "\n" .. (fs.readfile(TEMPLATE_STRONGSWAN_PUBKEY) or "")

    -- Update CA certificate if needed.
    -- The operation requires ipsec restart, therefore it is slow
    -- but it is rare case that CA should be updated, so first
    -- check the actual one, and if it does not match with
    -- desired one - update it and restart service
    local cacert = fs.readfile(crypto.ca)
    local curcert = fs.readfile(IPSEC_CA)

    if cacert ~= curcert or not ipsec_check_ca() then
        print("New CA detected. Updating config")
        fs.writefile(IPSEC_CA, cacert)
        
        -- slow, but very rare
        os.execute("ipsec restart")
    else
        print("Cached CA detected. Continuing")
    end
    
    -- Add private key and include it
    local pubkey_secrets = PUBKEY_SECRETS_FMT:format(crypto.priv)
    fs.writefile(RUN_PUBKEY_SECRETS, pubkey_secrets)
    include_config(IPSEC_SECRETS, RUN_PUBKEY_SECRETS)

    return {
        ipsec = ipsec_conf_format:format(id, crypto.cert, host),
        strongswan = strongswan_conf_format:format()
    }
end

--- Check if ipsec connection established
--
-- @param serv Not used
-- @return true If connection established
-- @return false If connection not established
local function ipsec_is_ready(serv)
    local ipsec_cmd = io.popen("ipsec status " .. IPSEC_CONN, "r")
    local ipsec_status = ipsec_cmd:read("*a") or ""
    ipsec_cmd:close()

    if string.find(ipsec_status, "ESTABLISHED", 0, true) then
        return true
    end

    return false
end

--- Check tunnel connectivity using TCP ping
--
-- @param util Util module
-- @param port Port for tcping
-- @return true On successful ping
-- @return false On failed ping
local function ipsec_tcping(util, port)
    local status, err = pcall(util.tcping, IPSEC_BROKER_HOST, port)

    if not status then
        util.debug_print("ipsec up: " .. tostring(err))
    end

    return status
end

--- Refresh ipsec state and reread configs
--
-- @return true If ipsec state was refreshed successfully
-- @return false If failed to refresh ipsec state
local function ipsec_refresh_config()
    local isread = (os.execute("ipsec rereadall") == 0)
    local isupdate = (os.execute("ipsec update") == 0)
    return isread and isupdate
end

--- Setup ipsec tunnel
--
-- @param serv Ipsec server
-- @param timeout Timeout to connection attempt
-- @param cb Callback to execute on success
-- @param fail_cb Callback to execute on fail (timeout or error)
local function ipsec_setup(util, serv, timeout, cb, fail_cb)
    include_config(IPSEC_CONF, RUN_IPSEC_CONF)
    include_config(STRONGSWAN_CONF, RUN_STRONGSWAN_CONF)

    local cursor = uci.cursor()
    local id = cursor:get("wimark", "broker", "id") or ""

    local conf
    local crypto = crypto_path()
    if crypto then
        conf = ipsec_prepare_pubkey_config(id, serv.host, crypto)
        print("Cryptographic secrets detected. Using PUBKEY")
    else
        conf = ipsec_prepare_psk_config(id, serv.host)
        print("Cryptographic secrets not detected. Using PSK")
    end
    
    fs.writefile(RUN_IPSEC_CONF, conf.ipsec)
    fs.writefile(RUN_STRONGSWAN_CONF, conf.strongswan)

    util.debug_print("ipsec: Created runtime configs")

    ipsec_refresh_config()
    util.uprocess(IPSEC_BIN, {"up", IPSEC_CONN}, timeout, function()

        -- Here 'ipsec up' command was executed successfully,
        -- however there are 2 other stages to check connection state:
        --   1. Check if ipsec really ready by checking its status
        --     1.1 If not ready, give it several tries to check,
        --         with some timeout between retries
        --     1.2 If ready, go to stage 2
        --   2. Ipsec service tells it is ready, but we need to check
        --      actual connectivity via tcping.
        --     2.1 If tcping does not pass, give it several tries, as in
        --         stage 1 with status checks
        --     2.2 If tcping passes, connection is considered to be established
        --         successfully
        --
        -- If on some stage a number of tries exceeded limit and success
        -- was not reached, connection considered to be failed.

        local _ipsec_is_ready = function()
            return ipsec_is_ready(serv)
        end

        -- Stage 1: ipsec status checks
        util.utry(_ipsec_is_ready, function()
            util.debug_print("ipsec: is_ready check initiated")

            -- Stage 1 success
            -- Stage 2: tcping checks
            util.utry(function()
                -- Check for actual connectivity to broker
                util.debug_print("ipsec: tcping check initiated")
                return ipsec_tcping(util, serv.port)
            end, function()
                -- Successfully established connection
                util.debug_print("ipsec tcping: success")
                cb(IPSEC_BROKER_HOST, serv.port)
            end, function()
                -- Failed to establish tcp connection
                util.debug_print("ipsec tcping: failure")
                fail_cb()
            end, IPSEC_TCPING_ATTEMPTS, IPSEC_TCPING_DELAY)

        end, function()

            -- Failed to establish connection, ipsec is not ready
            -- (Add 1 second delay to prevent overload)
            util.utimer(function()
                util.debug_print("ipsec up: Failed to establish connection")
                fail_cb()
            end, 1000)

        end, IPSEC_IS_READY_ATTEMPTS, IPSEC_IS_READY_DELAY)

    end, function()
        -- Command 'ipsec up' did not respond in timeout,
        -- connection is considered to be failed
        util.debug_print("ipsec up: Timeout exceeded")
        fail_cb()
    end)
end

--- Cleanup ipsec connection
--
-- @param serv Ipsec server
-- @param timeout Timeout to disconnect attempt
-- @param cb Callback to execute on success
-- @param fail_cb Callback to execute on fail (timeout or error)
local function ipsec_cleanup(util, serv, timeout, cb, fail_cb)

    -- Remove configuration first in order to prevent autoconnect
    fs.remove(RUN_IPSEC_CONF)
    fs.remove(RUN_STRONGSWAN_CONF)
    fs.remove(RUN_PUBKEY_SECRETS)

    util.debug_print("ipsec: Deleted runtime configs")

    -- First, try to softly down tunnel with 'ipsec down' command,
    -- but if it does not respond in time limit, force restart ipsec

    ipsec_refresh_config()
    util.uprocess(IPSEC_BIN, {"down", IPSEC_CONN}, timeout, function()
        util.debug_print("ipsec down: Success")
        cb()
    end, function()
        -- ipsec down did not respond in timeout,
        -- force restart ipsec
        util.uprocess(IPSEC_BIN, {"restart"}, timeout, function()
            util.debug_print("ipsec down: Success with force restart")
            cb()
        end, function()
            util.debug_print("ipsec down: Failed to restart ipsec: timeout exceeded")
            fail_cb()
        end)
    end)
end

return {
    setup = ipsec_setup,
    cleanup = ipsec_cleanup
}
