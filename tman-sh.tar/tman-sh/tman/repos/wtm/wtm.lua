-- Copyright (C), 2023, Wimark Systems, LLC ("Wimark").
-- All Rights Reserved.
--
-- This software contains the intellectual property of Wimark or is licensed
-- to Wimark from third parties. Use of this software and the intellectual
-- property contained therein is expressly limited to the terms and conditions
-- of the License Agreement under which it is provided by Wimark.
--

--- Wimark Tunnel Manager
-- @module wtm
module("wtm", package.seeall)

local ubus = require "ubus"
local uloop = require "uloop"
local uci = require "uci"
local fs = require "nixio.fs"
local os = require "os"
local socket = require "socket"

local orig_error = error

local UBUS_TIMEOUT_SEC = 1 --- Ubus connection timeout
local TCPING_TIMEOUT_SEC = 3 --- TCP ping timeout
local TCPING_ATTEMPTS = 3 --- TCP ping attempts before switcing broker
local TUNNEL_TIMEOUT_SEC = 20 --- Tunnel connection timeout before switching broker
local TUNNEL_DOWN_TIMEOUT_SEC = 3 --- Tunnel down timeout
local TIMEOUT_UNIT_MS = 1000 --- Timeout used to schedule jobs which should not capture current running flow
local REMOTE_WATCHDOG_MS = 5000 --- Timeout for establishing remote connection

local PRIMARY_ID = 1 --- Id of primary configurer
local SECONDARY_ID = 2 --- Id of secondary configurer
local TERTIARY_ID = 3 --- Id of tertiary configurer
local MAX_ID = 99999999 --- Maximum value of id, actually inaccessible

local OPT43_MIN_ID = 100
local OPT43_MAX_ID = 999
local OPT43_NAME = "dhcp_opt43"

local LOCALDOMAIN_ID = 1000
local LOCALDOMAIN_NAME = "manufacturing"
local LOCALDOMAIN_DEFAULT_HOST = "WIFI-CONTROLLER.localdomain"

local DEFAULT_LOCAL_HOST = "127.0.0.1" --- Default local host value
local DEFAULT_LOCAL_PORT = 1883 --- Default local port value

local DEFAULT_BROKER_PORT = 1883 --- Default broker port

local DHCP_OPT43_CHECK_TIMEOUT_SEC = 20 --- Option 43 check time interval

local FORWARDER_UBUS_NAME = "wimark.tunnel.wtm" --- Forwarder ubus service name
local UBUS_NAME = "wimark.tunnel" --- Ubus service name

local DOWN_WATCHDOG_MS = 15000 --- Watchdog timeout on tunnel down

local CONFIGURING_TUNNEL_STATUS = "Configuring tunnel"

local DEFAULT_NAMES = {"primary-base", "secondary-base", "tertiary-base"}

local DEBUG = false --- Enable/disable debug messages

uloop.init()
local conn = ubus.connect(nil, UBUS_TIMEOUT_SEC)

local util = {}

local wtm = {
    current_broker = nil,
    working_host = nil, --- Virtual address provided by tunnel setup
    working_port = nil,
    configuring_tunnel = false,
    is_up = false,
    watchdog = nil,
    dhcp_opt43_brokers = nil,
    timers = {},
    processes = {},
    reseting = false,
}

-- util functions (used in extensions)

--- Print message if debug mode is enabled (@see DEBUG)
--
-- @param format Format string to build message
-- @param ... Args to pass to format message
function util.debug_print(format, ...)
    if not DEBUG then
        return
    end

    local args = {...}
    xpcall(function()
        print(format:format(unpack(args)))
    end, function()
        print("Broken debug message:", format, unpack(args))
    end)
end

--- Get number of elements in table
--
-- @param t Source table
function util.table_len(t)
    local n = 0
    for _ in pairs(t) do
        n = n + 1
    end
    return n
end

--- Perform TCP ping request
--
-- @param host Host to ping
-- @param port Port to ping
-- TODO: Make tcping asynchronous (consider using util.uprocess and separate file)
function util.tcping(host, port)
    local tcp = assert(socket.tcp(), "Cannot create tcp socket")
    tcp:settimeout(TCPING_TIMEOUT_SEC)

    port = tonumber(port)
    local s, err = tcp:connect(host, port);
    if not s then
        error("TCPING ERROR: " .. err)
    end

    tcp:close()
    return true
end

--- Safely create **anonymous** timer (uloop)
--
-- @param cb Timer callback to call
-- @param delay Timer delay
function util.utimer(cb, delay)
    -- In uloop, timers created anonymously (without reference)
    -- have probability to be destroyed by garbage collector
    -- before its callback is executed. Therefore, this function
    -- creates global reference to timer and destroys it after
    -- callback was executed.
    local timer

    timer = uloop.timer(function()
        -- First, execute callback
        cb()

        -- Then cleanup retained reference
        for i, _ in pairs(wtm.timers) do
            if wtm.timers[i] == timer then
                -- Remove all references to the timer object
                wtm.timers[i] = nil
                timer = nil

                util.debug_print("Removed retained timer reference")
                util.debug_print(tostring(util.table_len(wtm.timers)) .. " retained timer references left")
            end
        end

    end, delay)

    table.insert(wtm.timers, timer)
end

--- Run executable in separate process asynchronously
--
-- @param executable Path to executable to run
-- @param args Array of input args for executable
-- @param timeout Timeout for process to finish (in milliseconds)
-- @param cb Callback to execute on process end
-- @param tcb Callback to execute on timeout exceeded (process killed)
function util.uprocess(executable, args, timeout, cb, tcb)
    local process, timer
    local process_canceled = false

    local function _cleanup_process(kill)
        -- Cleanup is executed only once
        if process_canceled then
            return
        end

        for i, _ in pairs(wtm.processes) do
            if wtm.processes[i].process == process then
                timer:cancel()

                if kill then
                    local pid = process:pid()
                    os.execute("kill -9 " .. tostring(pid))
                end

                -- Remove retained references
                wtm.processes[i].timer = nil
                wtm.processes[i].process = nil
                wtm.processes[i] = nil
                timer = nil
                process = nil

                util.debug_print("Removed retained reference to process")
                util.debug_print(tostring(util.table_len(wtm.processes)) .. " retained process references left")

                process_canceled = true
                return
            end
        end
    end

    -- Setup process timeout handler
    timer = uloop.timer(function()
        if not process_canceled then
            tcb()
            _cleanup_process(true)
        end
    end, timeout)

    -- Setup process handler
    process = uloop.process(executable, args, {}, function()
        if not process_canceled then
            cb()
            _cleanup_process(false)
        end
    end)

    table.insert(wtm.processes, {
        process = process,
        timer = timer
    })
end

--- Schedule function check until it returns true
--
-- @param targetfn Function to check for true value
-- @param cb Callback to execute if function returns true
-- @param fail_cb Callback to execute if function does not return true
-- @param attempts Maximum number of attempts for checks
-- @param delay Delay between attempts in milliseconds
function util.utry(targetfn, cb, fail_cb, attempts, delay)
    if attempts <= 0 then
        fail_cb()
        return
    end

    if not targetfn() then
        util.utimer(function()
            util.utry(targetfn, cb, fail_cb, attempts - 1, delay)
        end, delay)
    else
        cb()
    end
end

--- Check user input parameters
--
-- @param msg Input args table
-- @param params parameters to check in `msg'
-- @return on success - true
-- @return on failure - throw error and exit
local function check_user_input(msg, arguments)
    local default_arguments = {
        id = "number",
        name = "string",
        host = "string",
        tunnel_type = "string",
    }

    for _, arg_name in pairs(arguments) do
        local arg_type = default_arguments[arg_name]

        if not msg[arg_name] then
            error(("'%s' missing"):format(arg_name))
        elseif type(msg[arg_name]) ~= arg_type then
            error(("'%s' invalid type"):format(arg_name))
        end
    end

    return true
end

-- auxiliary functions

--- Get current module path for running path agnostic
--
-- @return Absolute module path
local function module_path()
    local script_path = debug.getinfo(1, 'S').source:sub(2)
    return fs.dirname(script_path) or ""
end

--- Get default tunnel name from symlink
--
-- @return Tunnel name
local function get_default_tunnel()
    local link = module_path() .. "/tunnels/default"
    local tunfile = fs.readlink(link) or "undefined"
    return string.gsub(tunfile, "%.lua$", "")
end

--- Cleanup invalid brokers
--
local function brokers_cleanup_invalid()
    -- The model of brokers storage had been changed,
    -- and the new one is incompatible with old one.
    -- Therefore, for the sake of stability there is an
    -- attempt to perform transition automatically.

    -- This code will erase static brokers which are considered
    -- to be invalid. Invalid brokers - those, which does not contain
    -- all the necessay fields (id, host, name, tunnel_type)

    -- This operation is neccessary because in some cases
    -- can overlap valid brokers ranges and break the logic.
    -- Therefore, it is not possible to just ignore them.

    local cursor = assert(uci.cursor())

    local required = {"id", "host", "name", "tunnel_type"}
    local invalid = {}

    -- Find invalid entities to remove
    cursor:foreach("wimark", "broker", function(broker)
        for _, param in ipairs(required) do
            if broker[param] == nil then
                table.insert(invalid, broker[".name"])
            end
        end
    end)

    for _, inv in ipairs(invalid) do
        cursor:delete("wimark", inv)
        print("Removed invalid host")
    end

    cursor:commit("wimark")
end

--- Check if localdomain resolving feature is enabled
--
-- @return true If localdomain feature is enabled
-- @return false If localdomain feature is disabled
local function is_localdomain_enabled()
    local cursor = assert(uci.cursor())
    return (cursor:get("wimark", "broker", "localdomain_disabled") ~= "1")
end

--- Get localdomain host
--
-- @return Localdomain host string
local function get_localdomain()
    local cursor = assert(uci.cursor())
    local host = cursor:get("wimark", "broker", "localdomain")
    return host or LOCALDOMAIN_DEFAULT_HOST
end

--- Iterate through all brokers (static, then opt43 and then localdomain)
--
-- @param func Function called during iteration process
local function for_each_broker(func)
    brokers_cleanup_invalid()

    local cursor = assert(uci.cursor())

    local tunnel_type = cursor:get("wimark", "broker", "tunnel") or ""

    if tunnel_type == "" then
        tunnel_type = "none"
    end

    -- First, add static brokers
    cursor:foreach("wimark", "broker", function(broker)
        broker.tunnel_type = tunnel_type
        broker.port = DEFAULT_BROKER_PORT
        broker.id = tonumber(broker.id)
        func(broker)
    end)

    -- Then, add DHCP option43 brokers
    local id43 = OPT43_MIN_ID
    for _, broker43 in ipairs(wtm.dhcp_opt43_brokers or {}) do
        if id43 > OPT43_MAX_ID then
            break
        end

        local name43 = ("%s-%d"):format(OPT43_NAME, id43)
        func({
            host = broker43.host,
            port = DEFAULT_BROKER_PORT,
            tunnel_type = tunnel_type,
            id = id43,
            name = name43
        })

        id43 = id43 + 1
    end

    if is_localdomain_enabled() then
        func({
            host = get_localdomain(),
            port = DEFAULT_BROKER_PORT,
            tunnel_type = tunnel_type,
            id = LOCALDOMAIN_ID,
            name = LOCALDOMAIN_NAME
        })
    end
end

--- Get current active broker
--
-- @return Broker instance table
local function get_active_broker()
    return wtm.current_broker
end

--- Get broker knowing its id
--
-- @param id Broker id
-- @return Broker instance table
local function get_broker_by_id(id)
    local found
    for_each_broker(function(broker)
        if broker.id == id then
            found = broker
            return
        end
    end)

    return found
end

--- Set current active broker
--
-- @param id Id of new current broker
local function set_active_broker(id)
    wtm.current_broker = get_broker_by_id(id)
end

--- Filter table for tunnel information options, omiting other parameters
--
-- @param options Table to filter options
-- @return Filtered table
local function filter_options(options)
    options = options or {}
    local opt = {}
    for _, k in ipairs({"id", "name", "host", "port", "tunnel_type"}) do
        opt[k] = options[k]
    end

    -- Convert these values into their correct types.
    opt.id = tonumber(opt.id)
    opt.port = tonumber(opt.port)
    return opt
end

--- List available broker ids
--
-- @return List with ids
local function list_brokers_ids()
    local ids = {}
    for_each_broker(function(broker)
        table.insert(ids, broker.id)
    end)

    table.sort(ids, function(a, b)
        a = a or MAX_ID
        b = b or MAX_ID
        return a < b
    end)

    return ids
end

--- Check if AP Fallback to Primary option is enabled
--
-- @return true If AP Fallback to Primary enabled
-- @return false If AP Fallback to Primary disabled
local function is_primary_fallback()
    local cursor = assert(uci.cursor())
    return cursor:get("wimark", "broker", "primary_fallback") == "1"
end

--- Throw error but without source info in error body
--
-- @param msg Error message
local function clean_error(msg)
    orig_error(msg, 0)
end

-- forwarder methods

--- Get current forwarder status
--
-- @return Forwarder checkup result
local function forwarder_checkup()
    return conn:call(FORWARDER_UBUS_NAME, "status", {})
end

--- Stop forwarder
--
local function forwarder_down()
    wtm.is_up = false
    conn:call(FORWARDER_UBUS_NAME, "shutdown", {})

    while forwarder_checkup() do
        print("Failed to shutdown forwarder. Retrying again")
    end

    -- Forwarder down means configuring process is cancelled
    wtm.configuring_tunnel = false
end

--- Start forwarder
--
-- @param local_host Local hostname
-- @param local_port Local port
-- @param remote_host Remote hostname
-- @param remote_port Remote port
-- @return Forwarder checkup result
-- @see forwarder_checkup
local function forwarder_up(local_host, local_port, remote_host, remote_port)
    forwarder_down()

    local cmd_fmt = "wtm-forwarder %s %s %s %s %s"
    os.execute(string.format(cmd_fmt, local_host, local_port, remote_host, remote_port, FORWARDER_UBUS_NAME))

    local checkup_attempts = 5
    local current_attempts = 0

    while not forwarder_checkup() and current_attempts < checkup_attempts do
        print(string.format("%s did not start yet. Retrying again", FORWARDER_UBUS_NAME))
        current_attempts = current_attempts + 1
    end

    -- Forwarder up means tunnel already configured
    wtm.configuring_tunnel = false

    local checkup = forwarder_checkup()
    wtm.is_up = (checkup ~= nil)
    return checkup
end

--- Setup watchdog
--
-- @param func Function to execute when timeout expires
-- @param timeout Timeout in milliseconds
local function watchdog_schedule(func, timeout)
    wtm.watchdog = uloop.timer(func, timeout)
end

--- Cancel watchdog
--
local function watchdog_cancel()
    if wtm.watchdog then
        wtm.watchdog:cancel()
        wtm.watchdog = nil
        print("Canceled watchdog")
    end
end

--- Handle local down event
--  (reconnection stuff)
--
-- @param msg Not used
local function local_down_handler(msg)
    print("Local connection was closed. Restarting")

    if not forwarder_up(DEFAULT_LOCAL_HOST, DEFAULT_LOCAL_PORT, wtm.working_host, wtm.working_port) then
        print("Failed to setup wtm-forwarder")
        wtm.discover()
    end
end

--- Handle remote down event
--  (perform reconnection stuff)
--
-- @param msg Not used
local function remote_down_handler(msg)
    print("Remote connection was closed. Trying to reconnect")
    local orig_id = get_active_broker().id

    local _timer = {}
    _timer.attempt = 0

    function _timer:reconnect()
        -- if broker was changes, do not continue
        local broker = get_active_broker()
        if broker.id ~= orig_id then
            return
        end

        local status, err = pcall(util.tcping, broker.working_host, broker.working_port)
        if status then
            if not forwarder_up(DEFAULT_LOCAL_HOST, DEFAULT_LOCAL_PORT, wtm.working_host, wtm.working_port) then
                print("Failed to setup wtm-forwarder")
                wtm.discover()
            end
            return
        end

        print("Reconnect attempt " .. tostring(_timer.attempt) .. ": Failed")

        _timer.attempt = _timer.attempt + 1
        if _timer.attempt < TCPING_ATTEMPTS then
            self:schedule_reconnect()
        else
            if not status then
                print("Failed to reconnect: " .. err .. ". Initiating Discover")
                wtm.discover()
            end
        end
    end

    function _timer:schedule_reconnect()
        util.utimer(function()
            _timer:reconnect()
        end, TIMEOUT_UNIT_MS)
    end

    _timer:schedule_reconnect()
end

--- Handle shutdown event
--  (schedule reconnection if shutdown is unexpected)
--
-- @param msg Not used
local function shutdown_handler(msg)
    watchdog_cancel();
    watchdog_schedule(function()
        if wtm.is_up and not forwarder_checkup() then
            print("Unexpected shutdown detected. Restarting tunnel")
            remote_down_handler(msg)
        end
    end, DOWN_WATCHDOG_MS)
end

--- Check if DHCP option 43 brokers list has changed in system
--
-- @return true if the list of opt43 brokers has changed
-- @return false if the list of opt43 brokers did not change
local function check_updates_dhcp_opt43()
    local function _opt43_tostring(brokers)
        local brokers_str = ""

        for _, broker in ipairs(brokers) do
            local interface = tostring(broker.interface or "")
            local host = tostring(broker.host or "")

            brokers_str = brokers_str .. interface .. ":" .. host .. ";"
        end

        return brokers_str
    end

    local dhcp_opt43_brokers = wtm.list_dhcp_opt43().brokers or {}

    if wtm.dhcp_opt43_brokers == nil then
        wtm.dhcp_opt43_brokers = dhcp_opt43_brokers
    end

    local cur_str = _opt43_tostring(wtm.dhcp_opt43_brokers)
    local new_str = _opt43_tostring(dhcp_opt43_brokers)

    return cur_str ~= new_str
end

--- Load tunnel module by name
--
-- @param tunnel_type Tunnel type string
-- @return Tunnel name, tunnel module if it exists
-- @return Default tunnel name, default tunnel module (@see get_default_tunnel) if desired module does not exist
local function load_tunnel(tunnel_type)
    tunnel_type = tostring(tunnel_type)
    local status, tunnel = pcall(require, "tunnels." .. tunnel_type)

    if not status then
        local default_tunnel = get_default_tunnel()
        util.debug_print("Failed to load tunnel '" .. tunnel_type .. "'. Falling back to '" .. default_tunnel .. "'")
        tunnel_type = default_tunnel
        tunnel = require("tunnels." .. tunnel_type)
    end

    return tunnel_type, tunnel
end

-- ubus handlers

--- Wrap function to make it able to reply as ubus method
--
-- @param func Function to wrap
-- @return Wrapped function
function wtm.ubus_wrap_function(func)
    local function wrapped(req, msg)
        local status, result = pcall(func, msg)
        if not status then
            conn:reply(req, {
                error = result
            })
        elseif result then
            conn:reply(req, result)
        end
    end
    return wrapped
end

--- Wrap object so its functions satisfy ubus format
--
-- @param obj Object to wrap
-- @return Object with functions wrapped by special ubus wrapper
-- @see wtm.ubus_wrap_function
function wtm.ubus_wrap_object(obj)
    local wrapped_obj = {}
    for name, spec in pairs(obj) do
        wrapped_obj[name] = {wtm.ubus_wrap_function(spec[1]), spec[2]}
    end
    return wrapped_obj
end

--- Assign tunnel configuration to some id
--
-- @param msg Input args table. Requires 'id', 'host', 'port' and 'tunnel_type' fields
function wtm.set_tunnel(msg)
    local cursor = assert(uci.cursor())

    -- Name is not neccessary required there because
    -- it can be implicitly assigned at the end
    local required = {"id", "host", "tunnel_type"}
    local new_tunnel = {}

    check_user_input(msg, required)

    for _, k in ipairs(required) do
        if not msg[k] then
            error(("'%s' is missing"):format(k))
        end

        new_tunnel[k] = msg[k]
    end

    -- Check if id is allowed
    local new_id = new_tunnel.id
    local allowed_ids = {PRIMARY_ID, SECONDARY_ID, TERTIARY_ID}
    local is_allowed = false

    for _, allowed_id in ipairs(allowed_ids) do
        if new_id == allowed_id then
            is_allowed = true
        end
    end

    if not is_allowed then
        error(("This id value is not allowed: '%s'"):format(new_tunnel.id))
    end

    -- Allow to set name explicitly
    -- (If not set - assign it implicitly)
    local implicit_name = ("%s-%d"):format(tostring(DEFAULT_NAMES[new_id]), new_id)
    new_tunnel.name = msg.name or implicit_name

    -- Check if the tunnel with such id already exists.
    -- If so - modify existing tunnel, otherwise - create new one.

    local name
    local existing_tunnel = get_broker_by_id(new_tunnel.id)

    if existing_tunnel then
        name = existing_tunnel[".name"]
    else
        name = cursor:add("wimark", "broker")
    end

    for option, value in pairs(new_tunnel) do
        cursor:set("wimark", name, option, value)
    end
    cursor:commit("wimark")

    -- If AP Fallback to Primary is enabled and primary
    -- configurer was modified - reconnect to it immediatelly
    if is_primary_fallback() and new_id == PRIMARY_ID then
        print("AP Fallback to Primary activated")
        wtm.discover()
    end
end

--- Delete existing tunnel
--
-- @param msg Input args table. Requires 'id' field
function wtm.delete_tunnel(msg)
    check_user_input(msg, {"id"})

    local cursor = assert(uci.cursor())
    local broker = get_broker_by_id(msg.id)

    if not broker then
        error("Broker with id=" .. tostring(msg.id) .. " does not exist")
    elseif broker.id >= OPT43_MIN_ID and broker.id <= OPT43_MAX_ID then
        error(("Broker with id=%d is got by DHCP option 43"):format(msg.id))
    elseif broker.id == LOCALDOMAIN_ID then
        local errfmt = "Broker with id=%d is a local domain. Cannot be deleted."
        error(errfmt:format(msg.id))
    end

    cursor:delete("wimark", broker[".name"])
    cursor:commit("wimark")
end

--- Get current service status
--
-- @param msg Not used
-- @return Table with service status information, including fields:
--         1. `local`: local connection address;
--         2. `remote`: remote connection info (tunnel connection address);
--         3. `original_remote`: remote connection info (real connection address);
--         4. `status`: Current state of service;
function wtm.status(msg)
    check_user_input(msg, {})

    local status = filter_options(get_active_broker())
    status.status = "Down"

    -- Actual and specified tunnel type may mismatch if
    -- specified one does not exist. Due to this reason
    -- current tunnel type is checked via load_tunnel()
    local tunnel_type, _ = load_tunnel(status.tunnel_type)
    status.tunnel_type = tunnel_type

    local forwarder_status = forwarder_checkup()
    if forwarder_status then
        status.status = forwarder_status.status

        status.broker = {
            ["local"] = {
                host = forwarder_status.local_conn_host,
                port = forwarder_status.local_conn_port
            },

            ["remote"] = {
                host = forwarder_status.remote_host,
                port = forwarder_status.remote_port
            },

            ["original_remote"] = {
                host = status.host,
                port = status.port
            }
        }
    end

    status.host = nil
    status.port = nil

    if wtm.configuring_tunnel then
        status.status = CONFIGURING_TUNNEL_STATUS
    end

    return status
end

--- Get information about separate tunnel by id
--
-- @param msg Input args table. Requires 'id'
-- @return Information about tunnel entity (@see get_broker_by_id)
function wtm.get(msg)
    check_user_input(msg, {"id"})

    local id = msg.id
    local broker = get_broker_by_id(id)

    if not broker then
        error("Broker with such id not found")
    end

    return filter_options(broker)
end

--- Enable tunnel forwarder
--
-- @param msg Not used
-- @return Current service status
-- @throws error If setup already in progress
-- @see wtm.status
function wtm.up(msg)
    check_user_input(msg, {})

    local function _tunnel_msg(msg, ...)
        print("wtm.up: " .. msg:format(...))
    end

    forwarder_down()

    local broker = get_active_broker()
    local broker_ids = list_brokers_ids()

    if util.table_len(broker_ids) == 0 then
        error("No brokers")
    end

    if not broker then
        set_active_broker(broker_ids[1])
        broker = get_active_broker()
    end

    local orig_id = broker.id

    -- Setup tunnel
    local tunnel_type, tunnel = load_tunnel(broker.tunnel_type)

    -- Do not allow simultaneous tunnel setups
    if wtm.configuring_tunnel then
        error("Tunnel setup is already in progress")
    end
    wtm.configuring_tunnel = true

    util.debug_print("wtm.up: Initiate tunnel cleanup for %s", broker.host)
    tunnel.cleanup(util, broker, TUNNEL_DOWN_TIMEOUT_SEC * 1000, function()
        util.debug_print("wtm.up: Initiate tunnel setup for %s", broker.host)
        tunnel.setup(util, broker, TUNNEL_TIMEOUT_SEC * 1000, function(host, port)
            wtm.working_host = host
            wtm.working_port = port

            _tunnel_msg("Established tunnel to %s", broker.host)

            if not forwarder_up(DEFAULT_LOCAL_HOST, DEFAULT_LOCAL_PORT, host, port) then
                _tunnel_msg("Failed to setup wtm-forwarder")
                wtm.next()
            end

        end, function()
            wtm.working_host = nil
            wtm.working_port = nil

            -- Failed to configure tunnel, return back to idle state
            wtm.configuring_tunnel = false

            _tunnel_msg("Failed to setup tunnel to %s", broker.host)
            _tunnel_msg("Switching broker")
            wtm.next()
        end)
    end, function()
        _tunnel_msg("Failed to cleanup tunnel. Initiating discover")
        wtm.discover()
    end)

    return wtm.status(msg)
end

--- Disable tunnel forwarder
--
-- @param msg Not used
-- @return Current service status
-- @see wtm.status
function wtm.down(msg)
    check_user_input(msg, {})

    local broker = get_active_broker()

    if not broker then
        error("No default broker selected")
    end

    -- Cleanup tunnel
    local tunnel_type, tunnel = load_tunnel(broker.tunnel_type)

    util.debug_print("wtm.down: Stop forwarder")
    forwarder_down()

    util.debug_print("wtm.down: Initiate tunnel cleanup")

    local function _stub()
        -- Do nothing in callbacks
    end

    tunnel.cleanup(util, broker, TUNNEL_DOWN_TIMEOUT_SEC * 1000, _stub, _stub)

    return wtm.status(msg)
end

--- Initiate discovery procedure
--
-- @param msg Not used
-- @return Current service status
-- @throws error If trying to initiate discover while it is in progress
-- @see wtm.up
function wtm.discover(msg)
    check_user_input(msg, {})

    -- Discovery - a procedure of finding available
    -- configurer from the beginning of the list

    -- Actually the easiest way to achieve it - restart wtm service
    util.debug_print("Discovery process initiated: restarting service")
    os.execute("service wtm restart")
end

--- List available tunnels
--
-- @param msg Not used
-- @return List of available tunnel brokers
function wtm.list(msg)
    check_user_input(msg, {})

    local brokers = {}

    for_each_broker(function(options)
        table.insert(brokers, filter_options(options))
    end)

    table.sort(brokers, function(a, b)
        local A = a.id or MAX_ID
        local B = b.id or MAX_ID
        return A < B
    end)

    return {
        brokers = brokers
    }
end

--- Switch to another broker
--
-- @param msg Input args table. Requires 'id' field
-- @return Current service status
-- @see wtm.status
-- @see wtm.up
function wtm.switch(msg)
    check_user_input(msg, {"id"})

    local broker = get_broker_by_id(msg.id)

    if not broker then
        error("Broker with id=" .. tostring(msg.id) .. " does not exist")
    end

    set_active_broker(broker.id)
    return wtm.up(msg)
end

--- Switch to next available broker with higher id
--
-- @param msg Not used
-- @return Current service status
-- @see wtm.switch
-- @see wtm.status
function wtm.next(msg)
    local ids = list_brokers_ids()
    if util.table_len(ids) == 0 then
        error("Not able to switch: no brokers available")
    end

    local active_id = get_active_broker().id
    if not active_id then
        error("No default broker selected")
    end

    -- find default id pos
    local active_pos
    for i, id in ipairs(ids) do
        if id == active_id then
            active_pos = i
            break
        end
    end

    -- If active broker get deleted wtm service gotta be restarted.
    -- Otherwise switching to next broker is not gonna occur.
    if not active_pos then
        error("Active broker was deleted from the list. Restart the service.")
    end

    -- switch to the next broker by id
    local next_id = (active_pos ~= util.table_len(ids) and ids[active_pos + 1] or ids[1])
    return wtm.switch {
        id = next_id
    }
end

--- Reset current forwarding connection
--
-- @param msg Not used
-- @return Current service status
-- @see wtm.status
function wtm.reset_connection(msg)
    if wtm.reseting then
        error("Reseting in progess")
    end
    wtm.reseting = true

    if forwarder_checkup() then
        forwarder_down()
        if not forwarder_up(DEFAULT_LOCAL_HOST, DEFAULT_LOCAL_PORT, wtm.working_host, wtm.working_port) then
            print("Failed to setup wtm-forwarder")
            wtm.discover()
        else
            util.utimer(function()
                -- Shedule a checkup after reset is initiated
                -- in order to detect cases when connection failed
                -- to establish after reset and cpeagent continuously
                -- resets it in loop
                if wtm.is_up and not forwarder_checkup() then
                    util.debug_print("Forwarder post-checkup failed. Initiating discover")
                    wtm.discover()
                else
                    wtm.reseting = false
                end
            end, REMOTE_WATCHDOG_MS + TIMEOUT_UNIT_MS)
            -- Timer should not be less than timeout for
            -- forwarder to establish remote connection
            -- (see REMOTE_WATCHDOG_MS in wtm-forwarder)
        end
    end
    return wtm.status(msg)
end

--- List DHCP opt43 brokers
--
-- @param msg Not used
-- @return Table with element 'brokers', where brokers passed via dhcp option 43
--         are stored in the format {interface=<network interface>, host=<broker host>}
function wtm.list_dhcp_opt43(msg)
    -- if option 'disable_dhcp_permanent' is set to '1', dhcp opt 43 is disabled
    local cursor = assert(uci.cursor())

    if cursor:get("wimark", "broker", "disable_dhcp_permanent") == "1" then
        return {
            brokers = {}
        }
    end

    local dhcp_brokers = {}

    local ifaces = conn:call("network.interface", "dump", {})
    ifaces = ifaces and ifaces.interface or {}

    for _, iface in ipairs(ifaces) do
        if iface.data then
            for _, addr in ipairs(iface.data.nms or {}) do
                table.insert(dhcp_brokers, {
                    interface = iface.interface or "",
                    host = addr
                })
            end
        end
    end

    return {
        brokers = dhcp_brokers
    }
end

-- Register ubus object
--
local wtm_obj = {
    [UBUS_NAME] = wtm.ubus_wrap_object {
        set_tunnel = {wtm.set_tunnel, {
            id = ubus.INT32,
            name = ubus.STRING,
            host = ubus.STRING,
            tunnel_type = ubus.STRING
        }},

        delete_tunnel = {wtm.delete_tunnel, {
            id = ubus.INT32
        }},

        status = {wtm.status, {}},

        get = {wtm.get, {
            id = ubus.INT32
        }},

        up = {wtm.up, {}},

        down = {wtm.down, {}},

        discover = {wtm.discover, {}},

        list = {wtm.list, {}},

        switch = {wtm.switch, {
            id = ubus.INT32
        }},

        next = {wtm.next, {}},

        reset_connection = {wtm.reset_connection, {}},

        list_dhcp_opt43 = {wtm.list_dhcp_opt43, {}}
    }
}

local function main()
    -- Listen for local and remote down events
    --
    conn:listen{
        [FORWARDER_UBUS_NAME .. ".local_down"] = local_down_handler,
        [FORWARDER_UBUS_NAME .. ".remote_down"] = remote_down_handler,
        [FORWARDER_UBUS_NAME .. ".shutdown"] = shutdown_handler
    }

    package.path = package.path .. ";" .. module_path() .. "/?.lua"

    -- If debug is disabled redefine error
    if not DEBUG then
        error = clean_error
    end

    check_updates_dhcp_opt43()
    wtm.up()

    conn:add(wtm_obj)
    uloop.run()
end

if not _G._TEST then
    main()
else
    -- Make some local functions visible for testing
    wtm.check_updates_dhcp_opt43 = check_updates_dhcp_opt43
end

return wtm
