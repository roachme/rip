local modules = {"uci", "ubus", "socket", "uloop", "configs", "nixio.fs"}

local _ = match._ -- any matcher
local DEFAULT_TUNNEL = "ipsec"

local function reload_modules(module)

    if type(module) == "string" then
        package.loaded[module] = nil
        package.loaded[module] = require(module)
        _G[module] = require(module)
        return
    end

    for _, m in ipairs(modules) do
        package.loaded[m] = nil
        _G[m] = nil
    end

    for _, m in ipairs(modules) do
        package.loaded[m] = require(m)
        _G[m] = require(m)
    end
end

describe("Test wtm.lua", function()

    _G._TEST = true
    package.path = package.path .. ";test/lua/?.lua"

    before_each(function()

        -- Reload modules before each test in order
        -- to ensure that environment is clear
        reload_modules()
        _ = match._

        -- Create mock objects
        uci_mock = mock(uci, true)
        os_mock = mock(os, true)
        ubus_mock = mock(ubus, true)
        socket_mock = mock(socket, true)
        uloop_mock = mock(uloop, true)
        nixio_mock = mock(nixio, true)
        nixio_mock.fs = mock(nixio.fs, true)

        -- Create stubs for UCI
        stub(uci, "cursor", function()
            return uci
        end)

        stub(uci, "foreach", function(self, conf, sect, func)
            for _, u in pairs(configs.uci[conf][sect]) do
                if type(u) == "table" then
                    func(u)
                end
            end
        end)

        stub(uci, "get", function(self, conf, sect, opt)
            return configs.uci[conf][sect][opt]
        end)

        stub(uci, "set", function(self, conf, sect, opt, val)
            configs.uci[conf][sect][opt] = tostring(val)
        end)

        stub(uci, "delete", function(self, conf, sect)
            local s = configs.uci[conf][sect]
            configs.uci[conf][sect] = nil

            local to_del = 0
            for i, broker in ipairs(configs.uci.wimark.broker) do
                if broker == s then
                    to_del = i
                end
            end

            s = nil
            configs.uci.wimark.broker[to_del] = nil
        end)

        stub(uci, "add", function(self, conf, sect)
            local newid = #configs.uci[conf][sect] + 1
            local name = sect .. tostring(newid)

            table.insert(configs.uci[conf][sect], {
                [".name"] = name
            })
            configs.uci[conf][name] = configs.uci[conf][sect][newid]
            return name
        end)

        -- Create stubs for ubus
        stub(ubus, "connect", function(sock, timeout)
            return ubus
        end)

        stub(ubus, "call", function(self, service, method, args)
            return configs.ubus[service][method]
        end)

        -- Create stub for socket
        stub(socket, "tcp", function()
            return socket
        end)

        stub(socket, "connect", function(self, host, port)
            return configs.socket
        end)

        stub(nixio.fs, "readlink", function(path)
            return DEFAULT_TUNNEL .. ".lua"
        end)

        -- after mocks are installed, reload wtm
        reload_modules("wtm")
    end)

    after_each(function()
    end)

    _G._TEST = true
    package.path = package.path .. ";test/lua/?.lua"

    it("List available brokers (no localdomain, no opt43)", function()
        local list = wtm.list().brokers

        assert.is.equal(3, #list)
        assert.stub(uci.foreach).was.called_with(_, "wimark", "broker", _)

        assert.is.equal("first_host", list[1].host)
        assert.is.equal("second_host", list[2].host)
        assert.is.equal("third_host", list[3].host)
    end)

    it("Switch broker", function()
        wtm.up()

        local status = wtm.status()
        assert.is.equal(1, status.id)

        wtm.switch({
            id = 3
        })
        status = wtm.status()
        assert.is.equal(3, status.id)
    end)

    it("Switch to next broker", function()
        wtm.up()

        local status = wtm.status()
        assert.is.equal(1, status.id)

        wtm.next()
        status = wtm.status()
        assert.is.equal(2, status.id)
    end)

    it("Switch to next after last", function()
        wtm.up()

        local status = wtm.status()
        assert.is.equal(1, status.id)

        wtm.switch({
            id = 3
        })
        status = wtm.status()
        assert.is.equal(3, status.id)

        wtm.next()
        status = wtm.status()
        assert.is.equal(1, status.id)
    end)

    it("Fallback to default tunnel type", function()
        local invalid_tunnel = "invalid_tunnel"
        configs.uci.wimark.broker.tunnel = invalid_tunnel
        wtm.up()

        local list = wtm.list().brokers
        assert.is.equal(invalid_tunnel, list[2].tunnel_type)

        wtm.switch({
            id = 2
        })
        local status = wtm.status()

        assert.is.equal(2, status.id)
        assert.is.equal(DEFAULT_TUNNEL, status.tunnel_type)
    end)

    it("Initial connection state is down", function()
        assert.are.same("Down", wtm.status().status)
    end)

    it("Disabled DHCP option 43", function()
        configs.uci.wimark.broker.disable_dhcp_permanent = "1"

        wtm.check_updates_dhcp_opt43()
        wtm.up()

        local list43 = wtm.list_dhcp_opt43().brokers

        assert.stub(uci.get).was.called_with(_, "wimark", "broker", "disable_dhcp_permanent")
        assert.is.equal(0, #list43)

        local list = wtm.list().brokers
        assert.is.equal(3, #list)
    end)

    it("Enabled DHCP option 43", function()
        configs.uci.wimark.broker.disable_dhcp_permanent = "0"

        wtm.check_updates_dhcp_opt43()
        wtm.up()

        local list = wtm.list().brokers
        local list43 = wtm.list_dhcp_opt43().brokers

        assert.stub(uci.get).was.called_with(_, "wimark", "broker", "disable_dhcp_permanent")
        assert.is.equal(1, #list43)

        assert.is.equal(4, #list)

        assert.is.equal("opt43_host", list43[1].host)
        assert.is.equal("lan", list43[1].interface)

        assert.is.equal("opt43_host", list[4].host)
        assert.is.equal(100, list[4].id)
        assert.is.equal("dhcp_opt43-100", list[4].name)
    end)

    it("Disabled localdomain", function()
        wtm.up()

        assert.stub(uci.get).was.called_with(_, "wimark", "broker", "localdomain_disabled")
        local list = wtm.list().brokers
        assert.is.equal(3, #list)
    end)

    it("Enabled localdomain", function()
        configs.uci.wimark.broker.localdomain_disabled = "0"
        wtm.up()

        assert.stub(uci.get).was.called_with(_, "wimark", "broker", "localdomain_disabled")
        local list = wtm.list().brokers
        assert.is.equal(4, #list)

        assert.is.equal(1000, list[4].id)
        assert.is.equal("WIFI-CONTROLLER.localdomain", list[4].host)
        assert.is.equal("manufacturing", list[4].name)
    end)

    it("Enabled option 43 and localdomain", function()
        configs.uci.wimark.broker.disable_dhcp_permanent = "0"
        configs.uci.wimark.broker.localdomain_disabled = "0"

        wtm.check_updates_dhcp_opt43()
        wtm.up()

        assert.stub(uci.get).was.called_with(_, "wimark", "broker", "disable_dhcp_permanent")
        assert.stub(uci.get).was.called_with(_, "wimark", "broker", "localdomain_disabled")

        local list = wtm.list().brokers
        assert.is.equal(5, #list)

        assert.is.equal(100, list[4].id)
        assert.is.equal(1000, list[5].id)
    end)

    it("Down tunnel", function()
        local status

        status = wtm.status()
        assert.is.equal(status.status, "Down")

        wtm.up()
        status = wtm.status()
        assert.is.not_equal(status.status, "Down")

        wtm.down()
        assert.stub(ubus.call).was.called_with(_, "wimark.tunnel.wtm", "shutdown", _)
    end)

    it("Delete tunnel", function()
        wtm.up()
        wtm.delete_tunnel({
            id = 2
        })

        local list = wtm.list().brokers
        assert.is.equal(2, #list)
        assert.is.equal(3, list[2].id)
    end)

    it("Delete current tunnel", function()
        wtm.up()

        local status
        status = wtm.status()
        assert.is.equal(1, status.id)

        wtm.delete_tunnel({
            id = 1
        })
        status = wtm.status()

        -- Current configurer must be preserved until next discovery call
        assert.is.equal(1, status.id)
        assert.is.equal("broker-1", status.name)
    end)

    it("Switch to non-existent tunnel", function()
        wtm.up()

        pcall(wtm.switch, {
            id = 4
        })
        local status = wtm.status()
        assert.is.not_equal(4, status.id)
    end)

    it("Set non-permitted tunnel id", function()
        local ok , _ =  pcall(wtm.set_tunnel, {id=4, host="somehost", tunnel_type="ipsec"})
        assert.is.not_equal(true, ok)
    end)

    it("Set non-existent permitted tunnel id", function()
        configs.uci.wimark.broker[2] = nil
        local ok , _ =  pcall(wtm.set_tunnel, {id=2, host="somehost", tunnel_type="ipsec"})
        assert.is.equal(true, ok)
    end)

    it("Set already existent permitted tunnel id", function()
        wtm.up()
        wtm.switch({id = 2})

        local status
        status = wtm.status()

        assert.is.equal(2, status.id)

        wtm.set_tunnel({id=2, host="otherhost", tunnel_type="ipsec"})

        -- Current connection must be preserved
        status = wtm.status()
        local list = wtm.list().brokers

        assert.are.equal(status.id, list[2].id)
        assert.are.not_equal(status.host, list[2].host)
    end)

    it("AP Primary Fallback is disabled", function()
        configs.uci.wimark.broker.primary_fallback = "0"
        wtm.up()
        wtm.switch({id = 2})

        local status
        status = wtm.status()
        assert.is.equal(2, status.id)

        wtm.set_tunnel({id=1, host="otherhost", tunnel_type="ipsec"})
        status = wtm.status()

        assert.is.not_equal(1, status.id)
    end)

    it("AP Primary Fallback is enabled", function()
        configs.uci.wimark.broker.primary_fallback = "1"
        wtm.up()
        wtm.switch({id = 2})

        local status
        status = wtm.status()
        assert.is.equal(2, status.id)

        wtm.set_tunnel({id=1, host="otherhost", tunnel_type="ipsec"})

        -- Actually wtm restarts and connects to first broker
        assert.stub(os.execute).was.called_with("service wtm restart")
    end)
end)
