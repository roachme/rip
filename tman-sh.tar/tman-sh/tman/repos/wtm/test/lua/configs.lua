local configs = {
    uci = {},
    ubus = {}
}

configs.uci = {
    wimark = {
        broker = {
            {
                id = "1",
                host = "first_host",
                tunnel_type = "ipsec",
                [".name"] = "broker1",
                ["name"] = "broker-1"
            },
            {
                id = "2",
                host = "second_host",
                tunnel_type = "none", -- no such tunnel, must fallback to ipsec
                [".name"] = "broker2",
                ["name"] = "broker-2"
            },
            {
                id = "3",
                host = "third_host",
                tunnel_type = "ipsec",
                [".name"] = "broker3",
                ["name"] = "broker-3"
            },
            disable_dhcp_permanent = "1",
            tunnel = "ipsec",
            localdomain_disabled = "1",
            primary_fallback = "1",
        }
    }
}

configs.uci.wimark.broker1 = configs.uci.wimark.broker[1]
configs.uci.wimark.broker2 = configs.uci.wimark.broker[2]
configs.uci.wimark.broker3 = configs.uci.wimark.broker[3]

configs.ubus = {
    ["wimark.tunnel.wtm"] = {
        ["shutdown"] = {}
    },

    ["wimark.apcm"] = {
        ["crypto_path"] = {}
    },

    ["network.interface"] = {
        ["dump"] = {
            ["interface"] = {{
                ["interface"] = "lan",
                ["up"] = true,
                ["pending"] = false,
                ["available"] = true,
                ["autostart"] = true,
                ["dynamic"] = false,
                ["proto"] = "static",
                ["device"] = "br-lan",
                ["data"] = {
                    ["nms"] = {"opt43_host"}
                }
            }}
        }
    }
}

configs.socket = 1

return configs
