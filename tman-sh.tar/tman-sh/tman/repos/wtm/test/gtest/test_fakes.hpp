#ifndef __TEST_FAKES_HPP_
#define __TEST_FAKES_HPP_

#include <gtest/gtest.h>

extern "C" {
#include <fff.h>

#include "forwarder.h"
#include "ubus.h"

DECLARE_FAKE_VALUE_FUNC(int, uloop_fd_add, struct uloop_fd *, unsigned int);
DECLARE_FAKE_VALUE_FUNC(int, uloop_fd_delete, struct uloop_fd *);
DECLARE_FAKE_VALUE_FUNC(int, uloop_timeout_set, struct uloop_timeout *, int);
DECLARE_FAKE_VALUE_FUNC(int, uloop_timeout_cancel, struct uloop_timeout *);

DECLARE_FAKE_VALUE_FUNC(int, ubus_send_reply, struct ubus_context *, struct ubus_request_data *, struct blob_attr *);
DECLARE_FAKE_VALUE_FUNC(int, ubus_send_event, struct ubus_context *, const char *, struct blob_attr *);
DECLARE_FAKE_VALUE_FUNC(int, ubus_add_object, struct ubus_context *, struct ubus_object *);
DECLARE_FAKE_VALUE_FUNC(const char *, ubus_strerror, int);

DECLARE_FAKE_VOID_FUNC(exit, int);
}

class ExitException {
   public:
    ExitException() = default;
};

void mock_exit(int status) noexcept(false);

class TestFixture : public ::testing::Test {
   protected:
    void SetUp() override;
    void TearDown() override;
};

class ForwarderTest : public TestFixture {};
class UbusTest : public TestFixture {};

#endif  // __TEST_FAKES_HPP_