#include "test_fakes.hpp"

// static functions to test (see GTEST definition)
int forwarder_shutdown_handler(struct ubus_context* ctx, struct ubus_object* obj, struct ubus_request_data* req, const char* method, struct blob_attr* msg);

TEST_F(UbusTest, ubus_register_forwarder_fail_add_object) {
    ubus_add_object_fake.return_val = 1;

    ASSERT_EQ(false, ubus_register_forwarder(NULL, "somepath"));
    ASSERT_EQ(1, ubus_add_object_fake.call_count);
}

TEST_F(UbusTest, ubus_register_forwarder_success_add_object) {
    ASSERT_EQ(true, ubus_register_forwarder(NULL, "somepath"));
    ASSERT_EQ(1, ubus_add_object_fake.call_count);
}

TEST_F(UbusTest, ubus_broadcast_event) {
    ubus_broadcast_event(NULL, "some.event");
    ASSERT_EQ(1, ubus_send_event_fake.call_count);
}

TEST_F(UbusTest, forwarder_shutdown_handler) {
    struct forwarder_config conf = {0};
    int rc = forwarder_shutdown_handler(&conf.context, NULL, NULL, NULL, NULL);

    ASSERT_EQ(UBUS_STATUS_OK, rc);
    ASSERT_EQ(true, uloop_cancelled);
}
