#include "test_fakes.hpp"

// static functions to test (see GTEST definition)
bool post_setup_local(struct forwarder_config *conf);
bool post_setup_remote(struct forwarder_config *conf);
void forward_frame(struct uloop_fd *ufd, unsigned int events);
bool start_forwarder(struct forwarder_config *conf);
void local_state_handler(struct forwarder_config *conf);
void remote_state_handler(struct forwarder_config *conf);
void watchdog_handler(struct uloop_timeout *watchdog);
void forwarder_state_handler(struct forwarder_config *conf);
void state_handler(struct uloop_fd *ufd, unsigned int events);

TEST_F(ForwarderTest, post_setup_local_fail_on_null) { ASSERT_EQ(false, post_setup_local(NULL)); }

TEST_F(ForwarderTest, post_setup_remote_fail_on_null) { ASSERT_EQ(false, post_setup_remote(NULL)); }

TEST_F(ForwarderTest, forward_frame_fail_on_null) { EXPECT_THROW(forward_frame(NULL, 0), ExitException); }

TEST_F(ForwarderTest, start_forwarder_fail_on_null) { ASSERT_EQ(false, start_forwarder(NULL)); }

TEST_F(ForwarderTest, local_state_handler_fail_on_null) { EXPECT_THROW(local_state_handler(NULL), ExitException); }

TEST_F(ForwarderTest, remote_state_handler_fail_on_null) { EXPECT_THROW(remote_state_handler(NULL), ExitException); }

TEST_F(ForwarderTest, watchdog_handler_fail_on_null) { EXPECT_THROW(watchdog_handler(NULL), ExitException); }

TEST_F(ForwarderTest, forwarder_state_handler_fail_on_null) { EXPECT_THROW(forwarder_state_handler(NULL), ExitException); }

TEST_F(ForwarderTest, state_handler_fail_on_null) { EXPECT_THROW(state_handler(NULL, 0), ExitException); }