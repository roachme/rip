#include "test_fakes.hpp"

extern "C" {

#include <fff.h>
#include <stdbool.h>

DEFINE_FFF_GLOBALS;
DEFINE_FAKE_VALUE_FUNC(int, uloop_fd_add, struct uloop_fd *, unsigned int);
DEFINE_FAKE_VALUE_FUNC(int, uloop_fd_delete, struct uloop_fd *);
DEFINE_FAKE_VALUE_FUNC(int, uloop_timeout_set, struct uloop_timeout *, int);
DEFINE_FAKE_VALUE_FUNC(int, uloop_timeout_cancel, struct uloop_timeout *);

DEFINE_FAKE_VALUE_FUNC(int, ubus_send_reply, struct ubus_context *, struct ubus_request_data *, struct blob_attr *);
DEFINE_FAKE_VALUE_FUNC(int, ubus_send_event, struct ubus_context *, const char *, struct blob_attr *);
DEFINE_FAKE_VALUE_FUNC(int, ubus_add_object, struct ubus_context *, struct ubus_object *);
DEFINE_FAKE_VALUE_FUNC(const char *, ubus_strerror, int);

DEFINE_FAKE_VOID_FUNC(exit, int);

bool uloop_cancelled = false;
}

void mock_exit(int status) noexcept(false) { throw ExitException(); }

void TestFixture::SetUp() {
    RESET_FAKE(uloop_fd_add);
    RESET_FAKE(uloop_fd_delete);
    RESET_FAKE(uloop_timeout_set);
    RESET_FAKE(uloop_timeout_cancel);

    RESET_FAKE(ubus_send_reply);
    RESET_FAKE(ubus_send_event);
    RESET_FAKE(ubus_add_object);
    RESET_FAKE(ubus_strerror);

    RESET_FAKE(exit);

    uloop_fd_add_fake.return_val = 0;
    uloop_fd_delete_fake.return_val = 0;
    uloop_timeout_set_fake.return_val = 0;
    uloop_timeout_cancel_fake.return_val = 0;

    ubus_send_reply_fake.return_val = 0;
    ubus_send_event_fake.return_val = 0;
    ubus_add_object_fake.return_val = 0;
    ubus_strerror_fake.return_val = "Some error";

    exit_fake.custom_fake = mock_exit;

    FFF_RESET_HISTORY();
    uloop_cancelled = false;
}

void TestFixture::TearDown() {}