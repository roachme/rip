#include <stdbool.h>

#include "mock__libubus.h"
#include "mock_libubox.h"
#include "ubus.h"
#include "unity.h"

TEST_FILE("ubus.c")

bool uloop_cancelled = false;

void setUp() {
    uloop_fd_add_IgnoreAndReturn(0);
    uloop_fd_delete_IgnoreAndReturn(0);
    uloop_timeout_set_IgnoreAndReturn(0);
    uloop_timeout_cancel_IgnoreAndReturn(0);
    ubus_handle_event_Ignore();
    ubus_send_reply_IgnoreAndReturn(0);
    ubus_send_event_IgnoreAndReturn(0);
    ubus_add_object_IgnoreAndReturn(0);
    ubus_strerror_IgnoreAndReturn("Some error");

    uloop_cancelled = false;
}
void tearDown(void) {}

void test_ubus_register_forwarder_fail_add_object(void) {
    ubus_add_object_StopIgnore();

    ubus_add_object_ExpectAnyArgsAndReturn(1);
    bool rb = ubus_register_forwarder(NULL, "somepath");

    TEST_ASSERT_EQUAL_INT(false, rb);
}

void test_ubus_register_forwarder_success_add_object(void) {
    ubus_add_object_StopIgnore();

    ubus_add_object_ExpectAnyArgsAndReturn(0);
    bool rb = ubus_register_forwarder(NULL, "somepath");

    TEST_ASSERT_EQUAL_INT(true, rb);
}

void test_ubus_broadcast_event(void) {
    ubus_send_event_StopIgnore();
    ubus_send_event_ExpectAnyArgsAndReturn(0);
    ubus_broadcast_event(NULL, "some.event");
}

void test_forwarder_shutdown_handler(void) {
    struct forwarder_config conf = {0};
    int rc = forwarder_shutdown_handler(&conf.context, NULL, NULL, NULL, NULL);

    TEST_ASSERT_EQUAL_INT(true, uloop_cancelled);
}
