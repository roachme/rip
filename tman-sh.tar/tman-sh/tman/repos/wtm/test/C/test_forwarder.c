#include <stdbool.h>

#include "forwarder.h"
#include "mock_libubox.h"
#include "mock_std.h"
#include "mock__libubus.h" // this should be mocked before ubus.h
#include "mock_ubus.h"
#include "unity.h"

TEST_FILE("forwarder.c")

bool uloop_cancelled = false;

void setUp() {
    uloop_fd_add_IgnoreAndReturn(0);
    uloop_fd_delete_IgnoreAndReturn(0);
    uloop_timeout_set_IgnoreAndReturn(0);
    uloop_timeout_cancel_IgnoreAndReturn(0);
    mock_exit_Ignore();
}

void tearDown(void) {}

void test_post_setup_local_fail_on_null(void) {
    TEST_ASSERT_EQUAL_INT(NULL, post_setup_local(NULL));
}

void test_post_setup_remote_fail_on_null(void) {
    TEST_ASSERT_EQUAL_INT(NULL, post_setup_remote(NULL));
}

void test_forward_frame_fail_on_null(void) {
    mock_exit_StopIgnore();
    mock_exit_ExpectAnyArgs();
    forward_frame(NULL, 0);
}

void test_start_forwarder_fail_on_null(void) {
    TEST_ASSERT_EQUAL_INT(false, start_forwarder(NULL));
}

void test_local_state_handler_fail_on_null(void) {
    mock_exit_StopIgnore();
    mock_exit_ExpectAnyArgs();
    local_state_handler(NULL);
}

void test_remote_state_handler_fail_on_null(void) {
    mock_exit_StopIgnore();
    mock_exit_ExpectAnyArgs();
    remote_state_handler(NULL);
}

void test_watchdog_handler_fail_on_null(void) {
    mock_exit_StopIgnore();
    mock_exit_ExpectAnyArgs();
    watchdog_handler(NULL);
}

void test_forwarder_state_handler_fail_on_null(void) {
    mock_exit_StopIgnore();
    mock_exit_ExpectAnyArgs();
    forwarder_state_handler(NULL);
}

void test_state_handler_fail_on_null(void) {
    mock_exit_StopIgnore();
    mock_exit_ExpectAnyArgs();
    state_handler(NULL, 0);
}