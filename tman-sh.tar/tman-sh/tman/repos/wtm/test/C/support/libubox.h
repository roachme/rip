#ifndef _ULOOP_H__
#define _ULOOP_H__

#include <stdbool.h>

#define ULOOP_READ              (1 << 0)
#define ULOOP_WRITE             (1 << 1)
#define ULOOP_EDGE_TRIGGER      (1 << 2)
#define ULOOP_BLOCKING          (1 << 3)

extern bool uloop_cancelled;

struct uloop_timeout {};
struct uloop_fd {};

int uloop_fd_add(struct uloop_fd *sock, unsigned int flags);
int uloop_fd_delete(struct uloop_fd *sock);
int uloop_timeout_set(struct uloop_timeout *timeout, int msecs);
int uloop_timeout_cancel(struct uloop_timeout *timeout);

static inline void uloop_end(void)
{
        uloop_cancelled = true;
}

#endif // _ULOOP_H__