#ifndef __STDLIB_MOCK_
#define __STDLIB_MOCK_

void mock_exit(int status);

#endif // __STDLIB_MOCK_