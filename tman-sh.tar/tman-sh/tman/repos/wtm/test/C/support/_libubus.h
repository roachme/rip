#ifndef __LIBUBUS_H
#define __LIBUBUS_H

#include <libubox/blobmsg.h>

struct ubus_context {};
struct ubus_object {};
struct ubus_request_data{};

void ubus_handle_event(struct ubus_context *ctx);
int ubus_send_reply(struct ubus_context *ctx, struct ubus_request_data *req, struct blob_attr *msg);
int ubus_send_event(struct ubus_context *ctx, const char *id, struct blob_attr *data);
int ubus_add_object(struct ubus_context *ctx, struct ubus_object *obj);
const char *ubus_strerror(int error);

#endif  // __LIBUBUS_H