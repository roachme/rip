# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]


## [1.0.11] - 2024-08-05

### Add

- wtm.lua: Add checker to command delete_tunnel and hotfix to command next


## [1.0.10] - 2024-07-15

### Fixed

- wtm.lua: Fix type confusion


## [1.0.9] - 2024-06-27

### Add

- test/lua: Add user input checker.


## [1.0.8] - 2024-05-24

### Fixed

- wtm: Fix connecting loop to unreachable hosts.


## [1.0.7] - 2024-05-23

### Fixed

- ipsec: Cleanup configuration files in order to prevent tunnel autoload


## [1.0.6] - 2024-04-24

### Added

- wtm: Limit range of availavle static ids.
- wtm: Add optional 'name' field for each configurer.
- ubus: Add method 'get' for convenience.
- ubus: Add method 'discover' for searching available configurer.
- wtm: Add localdomain address support.

### Changed

- ubus: Rename 'add_tunnel' method to 'set_tunnel'.
- wtm: Reprioritize DHCP Option 43 brokers.
- wtm: Do not reset ANY connection until Discover.

### Removed

- wtm: Port is not more specified explicitly.


## [1.0.5] - 2024-04-02

### Added

- tunnels: Add 'none' tunnel (revert it back).
- ipsec: Add back compatibility with current platform (again).
- ipsec: Add option to disable encryption for PSK connection.

### Changed

- tunnels: Manage default tunnel externally using symlinks.


## [1.0.4] - 2024-03-13

### Added

- ipsec: Add support to PUBKEY and PSK authentication.

### Changed

- wtm: Move to more asynchronous model.
- ipsec: Use more appropriate commands for control.
- ipsec: Enforce encryption.
- tests: Update unit tests.

### Removed

- Remove 'none' tunnel type.
- Remove no-encryption mode.


## [1.0.3] - 2024-02-12

### Added

- Unit tests by Google Test and FFF frameworks


## [1.0.2] - 2024-01-12

### Added

- DHCP option 43 support


## [1.0.1] - 2024-01-09

### Added

- Try to guess missing attributes for broker.


## [1.0.0] - 2023-12-15

### Added

- Ubus service `wimark.tunnel`.
- None and IPsec tunnels support.
- Traffic forwarder between local and remote endpoints.

### Deprecated

- Use global uci variable `wimark.broker.tunnel` for defining tunnel type. Will be deleted in future releases.
