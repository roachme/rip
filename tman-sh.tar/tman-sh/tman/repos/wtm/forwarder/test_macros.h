/**
  * @file      test_macros.h
  *
  * @brief     Macros applied while testing
  *
  * @date      2023-11-24
  *
  * @par
  * Copyright (C), 2023, Wimark Systems, LLC ("Wimark").
  * All Rights Reserved.
  *
  * This software contains the intellectual property of Wimark
  * or is licensed to Wimark from third parties. Use of this
  * software and the intellectual property contained therein is expressly
  * limited to the terms and conditions of the License Agreement under which
  * it is provided by Wimark.
  *
  */

/** \addtogroup Testing
*  @{
*/

#ifndef __TEST_MACROS_H_
#define __TEST_MACROS_H_

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
 * DEFINES
 ******************************************************************************/

#ifdef TEST

#define static
#define exit(code)                  \
            do {                    \
                mock_exit(code);    \
                return;             \
            } while(0);

#endif // TEST

#ifdef GTEST

#define static
#define UBUS_OBJECT_TYPE(...) {0}

#endif // GTEST

/******************************************************************************
 * PUBLIC TYPES
 ******************************************************************************/

#ifdef __cplusplus
}
#endif

#endif // __TEST_MACROS_H_

/** @}*/
