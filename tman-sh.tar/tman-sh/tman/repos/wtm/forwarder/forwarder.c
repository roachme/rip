/**
 * @file      forwarder.c
 *
 * @brief     Setup traffic forwarder between local and remote endpoints
 *
 * @date      2023-11-22
 *
 * @par
 * Copyright (C), 2023, Wimark Systems, LLC ("Wimark").
 * All Rights Reserved.
 *
 * This software contains the intellectual property of Wimark
 * or is licensed to Wimark from third parties. Use of this
 * software and the intellectual property contained therein is expressly
 * limited to the terms and conditions of the License Agreement under which
 * it is provided by Wimark.
 *
 */

/** \addtogroup Forwarder
 *  @{
 */

/******************************************************************************
 * INCLUDES
 ******************************************************************************/

#include "forwarder.h"

#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "test_macros.h"

/******************************************************************************
 * DEFINES, CONSTS, ENUMS
 ******************************************************************************/

#define BUFFER_SIZE 8192

#define REMOTE_WATCHDOG_MS 5000

#define LOCAL_IDLE  5
#define LOCAL_INTVL 1
#define LOCAL_CNT   1

#define REMOTE_IDLE  3
#define REMOTE_INTVL 1
#define REMOTE_CNT   3

#define exit_stub(code)                                 \
    do {                                                \
        printf("wtm-forwarder: exit (%d)\n", __LINE__); \
        exit(code);                                     \
    } while (0)                                         \

#define exit(code) exit_stub(code);

/******************************************************************************
 * PRIVATE TYPES
 ******************************************************************************/

typedef void (*state_handler_f)(struct forwarder_config *);

/******************************************************************************
 * PRIVATE FUNCTION PROTOTYPES
 ******************************************************************************/

static struct addrinfo * resolve_host(char * hostname, char * port);
static bool              socket_make_reusable(int fd);
static bool              socket_set_blocking(int fd, bool blocking);
static bool              socket_set_keepalive(int sock, int idle, int cnt, int intvl);
static int               setup_local(char * host, char * port);
static int               setup_remote(char * host, char * port);
static bool              socket_has_error(int fd);
static bool              socket_writable(int sockfd);
static bool              post_setup_local(struct forwarder_config * conf);
static bool              socket_get_addr_str(int fd, char host[ADDR_STR_SIZE], char port[ADDR_STR_SIZE]);
static bool              post_setup_remote(struct forwarder_config * conf);
static void              forward_frame(struct uloop_fd * ufd, unsigned int events);
static bool              start_forwarder(struct forwarder_config * conf);
static void              local_state_handler(struct forwarder_config * conf);
static void              watchdog_handler(struct uloop_timeout * watchdog);
static void              remote_state_handler(struct forwarder_config * conf);
static void              forwarder_state_handler(struct forwarder_config * conf);
static void              state_handler(struct uloop_fd * ufd, unsigned int events);

static state_handler_f state_handlers[] = {
    [STATE_SETUP_LOCAL]  = local_state_handler,
    [STATE_SETUP_REMOTE] = remote_state_handler,
    [STATE_FORWARDING]   = forwarder_state_handler,
};

/******************************************************************************
 * PRIVATE FUNCTIONS
 ******************************************************************************/

/**
 * @brief Resolve hostname to obtain actual network address
 *
 * @param hostname Hostname to resolve
 * @param port Port of remote endpoint
 * @return Address info structure with remote endpoint information
 */
static struct addrinfo * resolve_host(char * hostname, char * port)
{
    struct addrinfo   hints = {0};
    struct addrinfo * p_res = NULL;

    memset(&hints, 0, sizeof(hints));
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_family   = PF_UNSPEC;

    if (getaddrinfo(hostname, port, &hints, &p_res))
    {
        return NULL;
    }

    return p_res;
}

/**
 * @brief Make socket immediatelly reusable after close
 *
 * @param fd Socket file descriptor
 * @return true on success
 * @return false in case of any error
 */
static bool socket_make_reusable(int fd)
{
    int status = 0;

    status = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &(int) {1}, sizeof(int));

    if (status < 0)
    {
        perror("Failed to set SO_REUSADDE");
        return false;
    }

    struct linger linger = {.l_onoff = 1, .l_linger = 0};
    status               = setsockopt(fd, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger));

    if (status < 0)
    {
        perror("Failed to set SO_LINGER");
        return false;
    }

    return true;
}

/**
 * @brief Set socket blocking flag
 *
 * @param fd Socket file descriptor
 * @param blocking Blocking flag to set
 * @return true on success
 * @return false in case of any error
 */
static bool socket_set_blocking(int fd, bool blocking)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (-1 == flags)
    {
        return false;
    }

    if (blocking)
    {
        flags &= ~O_NONBLOCK;
    }
    else
    {
        flags |= O_NONBLOCK;
    }

    return (fcntl(fd, F_SETFL, flags) != -1);
}

/**
 * @brief Configure TCP keepalive packets on socket for connection maintenance
 *
 * @param sock Socket file descriptor
 * @param idle Number of seconds connection should stay idle before sending keepalive probes
 * @param cnt Maximum number of keepalive probes before dropping connection
 * @param intvl Number of seconds between successive keepalive probes
 * @return true on success
 * @return false in case of any error
 */
static bool socket_set_keepalive(int sock, int idle, int cnt, int intvl)
{
    int status = 0;

    status = setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &(int) {1}, sizeof(int));
    if (status < 0)
    {
        perror("Failed to enable keepalive");
        return false;
    }

    status = setsockopt(sock, IPPROTO_TCP, TCP_KEEPCNT, &cnt, sizeof(cnt));
    if (status < 0)
    {
        perror("Failed to set TCP_KEEPCNT");
        return false;
    }

    status = setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof(idle));
    if (status < 0)
    {
        perror("Failed to set TCP_KEEPIDLE");
        return false;
    }

    status = setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &intvl, sizeof(intvl));
    if (status < 0)
    {
        perror("Failed to set TCP_KEEPINTVL");
        return false;
    }

    return true;
}

/**
 * @brief Initiates non-blocking socket, which listens for local connection request
 *
 * @param host Listening host (usually 127.0.0.1)
 * @param port Listening port
 * @return -1 in case of any error
 * @return Legal socket file descriptor ready for polling upon connection on success
 */
static int setup_local(char * host, char * port)
{
    struct addrinfo * addr = resolve_host(host, port);
    if (!addr)
    {
        fprintf(stderr, "Failed to resolve local host\n");
        return -1;
    }

    int sock = socket(addr->ai_family, addr->ai_socktype | SOCK_NONBLOCK, addr->ai_protocol);

    if (!socket_make_reusable(sock))
    {
        return -1;
    }

    if (bind(sock, addr->ai_addr, addr->ai_addrlen))
    {
        perror("Failed to bind socket");
        return -1;
    }

    if (listen(sock, 1))
    {
        perror("Failed to listen local address");
        return -1;
    }

    // TODO: what if connection will be accepted immediatelly
    if (accept(sock, NULL, NULL) < 0 && errno != EINPROGRESS && errno != EAGAIN)
    {
        perror("Failed to accept connection");
        return -1;
    }

    freeaddrinfo(addr);
    return sock;
}

/**
 * @brief Creates non-blocking socket, which initiates connection with remote peer
 *
 * @param host Remote peer hostname
 * @param port Remote peer port
 * @return -1 in case of any error
 * @return Legal socket file descriptor ready for polling upon connection on success
 */
static int setup_remote(char * host, char * port)
{
    struct addrinfo * addr = resolve_host(host, port);
    if (!addr)
    {
        fprintf(stderr, "Failed to resolve local host\n");
        return -1;
    }

    int sock = socket(addr->ai_family, addr->ai_socktype | SOCK_NONBLOCK, addr->ai_protocol);

    if (!socket_set_keepalive(sock, REMOTE_IDLE, REMOTE_CNT, REMOTE_INTVL))
    {
        return -1;
    }

    if (connect(sock, addr->ai_addr, addr->ai_addrlen) && errno != EINPROGRESS && errno != EAGAIN)
    {
        perror("Failed to connect to remote host");
        return -1;
    }

    freeaddrinfo(addr);
    return sock;
}

/**
 * @brief Check if socket has error
 *
 * @param fd Socket file descriptor
 * @return true if socket has error
 * @return false if socket does not have any errors
 */
static bool socket_has_error(int fd)
{
    int       err = 0;
    socklen_t len = sizeof(err);

    if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &len) < 0)
    {
        perror("Failed to obtain socket error code");
        return true;
    }

    if (err)
    {
        fprintf(stderr, "Socket has error: %s\n", strerror(err));
        return true;
    }

    return false;
}

/**
 * @brief Check if socket writable at the moment (used with non-blocking sockets)
 *
 * @param sockfd File descriptor of the socket
 * @return true if socket is writable at the moment
 * @return false if socket is not writable at the moment
 */
static bool socket_writable(int sockfd)
{
    struct pollfd fd = {
        .fd      = sockfd,
        .events  = POLLOUT,
        .revents = 0,
    };

    return poll(&fd, 1, 0) > 0 && (fd.revents & POLLOUT);
}

/**
 * @brief Post-setup operations on local connection socket
 *
 * @param conf Forwarder instance responsible for socket
 * @return true if post-setup stuff completed successfully
 * @return false if post-setup stuff failed at any point
 */
static bool post_setup_local(struct forwarder_config * conf)
{

    if (!conf)
    {
        return false;
    }

    int sock = conf->local_fd;

    conf->local_fd = accept(sock, NULL, NULL);
    close(sock);

    bool err = (conf->local_fd < 0);
    err |= socket_has_error(conf->local_fd);
    err |= (!socket_set_blocking(conf->local_fd, true));

    if (err)
    {
        ubus_broadcast_event(&conf->context, conf->ulocal.ubus_broadcast);
        perror("Failed to post-setup local connection");
        return false;
    }

    bool keepalive_status = socket_set_keepalive(conf->local_fd, LOCAL_IDLE, LOCAL_CNT, LOCAL_INTVL);
    bool reusable         = socket_make_reusable(conf->local_fd);

    return keepalive_status && reusable;
}

/**
 * @brief Obtain connection local host and port
 *
 * @param fd Socket descriptor of connection
 * @param host Buffer to write host string value
 * @param port Buffer to write port string value
 * @return true if address obtained successfully
 * @return false if failed to obtain address
 */
static bool socket_get_addr_str(int fd, char host[ADDR_STR_SIZE], char port[ADDR_STR_SIZE])
{
    struct sockaddr_in addr = {0};
    socklen_t          len  = sizeof(addr);

    if (getsockname(fd, (struct sockaddr *)&addr, &len) == -1)
    {
        return false;
    }

    strncpy(host, inet_ntoa(addr.sin_addr), ADDR_STR_SIZE);
    snprintf(port, ADDR_STR_SIZE, "%d", ntohs(addr.sin_port));

    return true;
}

/**
 * @brief Post-setup operations on remote connection socket
 *
 * @param conf Forwarder instance responsible for socket
 * @return true if post-setup stuff completed successfully
 * @return false if post-setup stuff failed at any point
 */
static bool post_setup_remote(struct forwarder_config * conf)
{

    if (!conf)
    {
        return false;
    }

    uloop_timeout_cancel(&conf->watchdog);

    if (!socket_set_blocking(conf->remote_fd, true))
    {
        perror("Failed to make remote socket blocking");
        ubus_broadcast_event(&conf->context, conf->uremote.ubus_broadcast);
        return false;
    }

    if (!socket_make_reusable(conf->remote_fd))
    {
        ubus_broadcast_event(&conf->context, conf->uremote.ubus_broadcast);
        return false;
    }

    if (!socket_get_addr_str(conf->remote_fd, conf->local_conn_host, conf->local_conn_port))
    {
        perror("Failed to obtain local address");
        ubus_broadcast_event(&conf->context, conf->uremote.ubus_broadcast);
        return false;
    }

    if (socket_has_error(conf->remote_fd))
    {
        perror("Failed to post-setup remote connection");
        ubus_broadcast_event(&conf->context, conf->uremote.ubus_broadcast);
        return false;
    }

    return true;
}

/**
 * @brief Forward single data frame from source to destination socket
 *
 * @param ufd Uloop file descriptor structure responsible for source socket events
 * @param events Events flag triggered by socket
 */
static void forward_frame(struct uloop_fd * ufd, unsigned int events)
{

    if (!ufd)
    {
        fprintf(stderr, "Fatal: NULL passed as uloop descriptor\n");
        exit(EXIT_FAILURE);
    }

    struct uframe * ufr = container_of(ufd, struct uframe, ufd);

    if (!socket_writable(ufr->dest_fd))
    {

#if 0
		printf("Socket is not ready for writing yet (%d)\n", ufr->dest_fd);
#endif
        return;
    }

    static char buf[BUFFER_SIZE] = {0};

    int rbytes = read(ufd->fd, buf, sizeof(buf));

#if 0
	printf("frame: %d -> %d (%d)\n", ufd->fd, ufr->dest_fd, r);
#endif

    if (rbytes <= 0)
    {
        if (rbytes < 0)
        {
            perror("Frame forwarding error occured");
        }
        ubus_broadcast_event(ufr->context, ufr->ubus_broadcast);
        uloop_end();
        return;
    }

    int wbytes = write(ufr->dest_fd, buf, rbytes);

    if (wbytes < 0)
    {
        perror("Failed to write frame");
        return;
    }

#if 0
	printf("wrote frame: %d -> %d (%d out of %d)\n", ufd->fd, ufr->dest_fd, w, r);
#endif
}

/**
 * @brief Register uloop events for forwarding traffic from remote to local and vise versa
 *
 * @param conf Forwarder instance containing configuration
 * @return true if forwarder was successfully registered to both peers
 * @return false if any error occur
 */
static bool start_forwarder(struct forwarder_config * conf)
{

    if (!conf)
    {
        return false;
    }

    conf->ulocal.ufd.fd  = conf->local_fd;
    conf->uremote.ufd.fd = conf->remote_fd;

    conf->ulocal.ufd.cb  = forward_frame;
    conf->uremote.ufd.cb = forward_frame;

    conf->ulocal.dest_fd  = conf->remote_fd;
    conf->uremote.dest_fd = conf->local_fd;

    conf->ulocal.context  = &conf->context;
    conf->uremote.context = &conf->context;

    if (uloop_fd_add(&conf->ulocal.ufd, ULOOP_READ | ULOOP_ERROR_CB))
    {
        fprintf(stderr, "Failed to add local connection to uloop\n");
        return false;
    }

    if (uloop_fd_add(&conf->uremote.ufd, ULOOP_READ | ULOOP_ERROR_CB))
    {
        fprintf(stderr, "Failed to add remote connection to uloop\n");
        return false;
    }

    ubus_broadcast_event(&conf->context, conf->up_broadcast);

    return true;
}

/**
 * @brief Handle forwarder local connection initialization stage
 *
 * @param conf Forwarder instance
 */
static void local_state_handler(struct forwarder_config * conf)
{

    if (!conf)
    {
        fprintf(stderr, "Fatal: NULL passed as forwarder instance\n");
        exit(EXIT_FAILURE);
    }

    conf->local_fd = setup_local(conf->local_host, conf->local_port);

    if (-1 == conf->local_fd)
    {
        exit(EXIT_FAILURE);
    }

    conf->ufd.fd = conf->local_fd;

    if (uloop_fd_add(&conf->ufd, ULOOP_READ | ULOOP_ERROR_CB))
    {
        perror("Failed to add fd to uloop");
        exit(EXIT_FAILURE);
    }
    conf->state = STATE_SETUP_REMOTE;
}

/**
 * @brief Handle watchdog (set to handle remote connection timeout)
 *
 * @param watchdog Uloop timeout object
 */
static void watchdog_handler(struct uloop_timeout * watchdog)
{

    if (!watchdog)
    {
        fprintf(stderr, "Fatal: NULL passed as watchdog timeout instance\n");
        exit(EXIT_FAILURE);
    }

    struct forwarder_config * conf = container_of(watchdog, struct forwarder_config, watchdog);

    fprintf(stderr, "Remote connection did not respond too long\n");
    ubus_broadcast_event(&conf->context, conf->uremote.ubus_broadcast);
    exit(EXIT_FAILURE);
}

/**
 * @brief Handle forwarder remote connection initialization stage
 *
 * @param conf Forwarder instance
 */
static void remote_state_handler(struct forwarder_config * conf)
{

    if (!conf)
    {
        fprintf(stderr, "Fatal: NULL passed as forwarder instance\n");
        exit(EXIT_FAILURE);
    }

    if (!post_setup_local(conf))
    {
        exit(EXIT_FAILURE);
    }

    printf("Local socket was successfully set up\n");

    conf->remote_fd = setup_remote(conf->remote_host, conf->remote_port);

    if (-1 == conf->remote_fd)
    {
        ubus_broadcast_event(&conf->context, conf->uremote.ubus_broadcast);
        exit(EXIT_FAILURE);
    }

    uloop_fd_delete(&conf->ufd);
    conf->ufd.fd = conf->remote_fd;
    uloop_fd_add(&conf->ufd, ULOOP_WRITE | ULOOP_ERROR_CB);

    conf->state = STATE_FORWARDING;

    conf->watchdog.cb = watchdog_handler;
    uloop_timeout_set(&conf->watchdog, REMOTE_WATCHDOG_MS);
}

/**
 * @brief Handle forwarder traffic forwarding initialization stage
 *
 * @param conf Forwarder instance
 */
static void forwarder_state_handler(struct forwarder_config * conf)
{
    uloop_fd_delete(&conf->ufd);

    if (!post_setup_remote(conf))
    {
        exit(EXIT_FAILURE);
    }

    printf("Remote socket was successfully set up\n");

    if (!start_forwarder(conf))
    {
        fprintf(stderr, "Failed to start forwarder\n");
        exit(EXIT_FAILURE);
    }
}

/**
 * @brief Handle current forwarder state
 *
 * @ref local_state_handler
 * @ref remote_state_handler
 * @ref forwarder_state_handler
 *
 * @param ufd Uloop file descriptor
 * @param event Triggered events on descriptor
 */
static void state_handler(struct uloop_fd * ufd, unsigned int events)
{

    if (!ufd)
    {
        fprintf(stderr, "Fatal: NULL passed as  uloop file descritor\n");
        exit(EXIT_FAILURE);
    }

    struct forwarder_config * conf = container_of(ufd, struct forwarder_config, ufd);
    state_handlers[conf->state](conf);
}

/******************************************************************************
 * PUBLIC FUNCTIONS
 ******************************************************************************/

/**
 * @brief Setup forwarder between local peer and remote peer
 *
 * @param context Forwarder instance
 * @return true
 */
bool setup_forwarder(struct forwarder_config * context)
{
    context->state  = STATE_SETUP_LOCAL;
    context->ufd.cb = state_handler;

    context->ufd.cb(&context->ufd, 0);
    return true;
}

/******************************************************************************
 * END OF SOURCE'S CODE
 ******************************************************************************/
/** @}*/
