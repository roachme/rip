/**
 * @file      ubus.c
 *
 * @brief     Ubus operations
 *
 * @date      2023-11-22
 *
 * @par
 * Copyright (C), 2023, Wimark Systems, LLC ("Wimark").
 * All Rights Reserved.
 *
 * This software contains the intellectual property of Wimark
 * or is licensed to Wimark from third parties. Use of this
 * software and the intellectual property contained therein is expressly
 * limited to the terms and conditions of the License Agreement under which
 * it is provided by Wimark.
 *
 */

/** \addtogroup Ubus
 *  @{
 */

/******************************************************************************
 * INCLUDES
 ******************************************************************************/

#include "ubus.h"

#include <libubus.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "test_macros.h"

/******************************************************************************
 * DEFINES, CONSTS, ENUMS
 ******************************************************************************/

static const char * forwarder_state_str[] = {
    [STATE_SETUP_LOCAL]  = "Setting up connection",
    [STATE_SETUP_REMOTE] = "Setting up connection",
    [STATE_FORWARDING]   = "Forwarding traffic",
};

/******************************************************************************
 * PRIVATE DATA
 ******************************************************************************/

static struct ubus_object ubus_obj = {0};

/******************************************************************************
 * PRIVATE FUNCTION PROTOTYPES
 ******************************************************************************/

static int forwarder_status_handler(struct ubus_context * ctx, struct ubus_object * obj, struct ubus_request_data * req, const char * method, struct blob_attr * msg);
static int forwarder_shutdown_handler(struct ubus_context * ctx, struct ubus_object * obj, struct ubus_request_data * req, const char * method, struct blob_attr * msg);

static struct ubus_method ubus_methods[] = {
    UBUS_METHOD_NOARG("status", forwarder_status_handler),
    UBUS_METHOD_NOARG("shutdown", forwarder_shutdown_handler),
};

static struct ubus_object_type ubus_objtype = UBUS_OBJECT_TYPE("forwarder", ubus_methods);

/******************************************************************************
 * PRIVATE FUNCTIONS
 ******************************************************************************/

/**
 * @brief Handle ubus `status` request
 *
 * @param ctx Ubus context
 * @param obj Ubus object
 * @param req Ubus request
 * @param method Ubus method
 * @param msg Ubus message
 * @return Ubus status code (UBUS_STATUS_OK on success)
 */
static int forwarder_status_handler(struct ubus_context * ctx, struct ubus_object * obj, struct ubus_request_data * req, const char * method, struct blob_attr * msg)
{
    struct forwarder_config * conf = container_of(ctx, struct forwarder_config, context);

    struct blob_buf buf = {0};
    memset(&buf, 0, sizeof(buf));
    blob_buf_init(&buf, 0);

    blobmsg_add_string(&buf, "local_host", conf->local_host);
    blobmsg_add_string(&buf, "local_port", conf->local_port);

    blobmsg_add_string(&buf, "remote_host", conf->remote_host);
    blobmsg_add_string(&buf, "remote_port", conf->remote_port);

    blobmsg_add_string(&buf, "status", forwarder_state_str[conf->state]);

    blobmsg_add_string(&buf, "local_conn_host", conf->local_conn_host);
    blobmsg_add_string(&buf, "local_conn_port", conf->local_conn_port);

    int err = ubus_send_reply(ctx, req, buf.head);

    if (err)
    {
        fprintf(stderr, "Failed to reply status: %s\n", ubus_strerror(err));
        blob_buf_free(&buf);
        return err;
    }

    blob_buf_free(&buf);
    return UBUS_STATUS_OK;
}

/**
 * @brief Handle ubus `shutdown` request
 *
 * @param ctx Ubus context
 * @param obj Ubus object
 * @param req Ubus request
 * @param method Ubus method
 * @param msg Ubus message
 * @return Ubus status code (UBUS_STATUS_OK on success)
 */
static int forwarder_shutdown_handler(struct ubus_context * ctx, struct ubus_object * obj, struct ubus_request_data * req, const char * method, struct blob_attr * msg)
{
    struct forwarder_config * conf = container_of(ctx, struct forwarder_config, context);

    printf("Shutdown scheduled\n");

    close(conf->local_fd);
    close(conf->remote_fd);

    uloop_end();
    return UBUS_STATUS_OK;
}

/******************************************************************************
 * PUBLIC FUNCTIONS
 ******************************************************************************/

/**
 * @brief Register forwarder ubus service
 *
 * @param ctx Ubus context
 * @param path Ubus service name
 * @return true on success
 * @return false in case of any errors
 */
bool ubus_register_forwarder(struct ubus_context * ctx, const char * path)
{
    memset(&ubus_obj, 0, sizeof(ubus_obj));

    ubus_obj.type      = &ubus_objtype;
    ubus_obj.methods   = ubus_methods;
    ubus_obj.n_methods = ARRAY_SIZE(ubus_methods);
    ubus_obj.name      = path;

    int err = ubus_add_object(ctx, &ubus_obj);

    if (err)
    {
        fprintf(stderr, "Failed to add ubus object: %s\n", ubus_strerror(err));
        return false;
    }

    return true;
}

/**
 * @brief Broadcast ubus event
 *
 * @param ctx Ubus context
 * @param path Event path to broadcast
 */
void ubus_broadcast_event(struct ubus_context * ctx, const char * path)
{
    struct blob_buf buf = {0};
    memset(&buf, 0, sizeof(buf));
    blob_buf_init(&buf, 0);

    ubus_send_event(ctx, path, buf.head);

    blob_buf_free(&buf);
}

/******************************************************************************
 * END OF SOURCE'S CODE
 ******************************************************************************/
/** @}*/
