/**
  * @file      ubus.h
  *
  * @brief     Ubus operations
  *
  * @date      2023-11-22
  *
  * @par
  * Copyright (C), 2023, Wimark Systems, LLC ("Wimark").
  * All Rights Reserved.
  *
  * This software contains the intellectual property of Wimark
  * or is licensed to Wimark from third parties. Use of this
  * software and the intellectual property contained therein is expressly
  * limited to the terms and conditions of the License Agreement under which
  * it is provided by Wimark.
  *
  */

/** \addtogroup Ubus
*  @{
*/

#ifndef __UBUS_H_
#define __UBUS_H_

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
 * INCLUDES
 ******************************************************************************/

#include <libubus.h>
#include <libubox/uloop.h>
#include <stdbool.h>

/******************************************************************************
 * DEFINES
 ******************************************************************************/

#define BROADCAST_EVENT_SIZE 32
#define ADDR_STR_SIZE        32

/******************************************************************************
 * PUBLIC TYPES
 ******************************************************************************/

enum forwarder_state {
	STATE_SETUP_LOCAL = 0,
	STATE_SETUP_REMOTE = 1,
	STATE_FORWARDING = 2,
};

struct uframe {
	struct uloop_fd ufd;

	int dest_fd;
	char ubus_broadcast[BROADCAST_EVENT_SIZE];
	struct ubus_context *context;
};

struct forwarder_config {
	struct uloop_fd ufd;

	char *local_host, *local_port;
	char *remote_host, *remote_port;
	char *instance;

	struct ubus_context context;
	enum forwarder_state state;
	char up_broadcast[BROADCAST_EVENT_SIZE];
	char down_broadcast[BROADCAST_EVENT_SIZE];

	int local_fd, remote_fd;
	struct uframe ulocal, uremote;

	struct uloop_timeout watchdog;

    //local connection to remote host info
    char local_conn_host[ADDR_STR_SIZE];
    char local_conn_port[ADDR_STR_SIZE];
};

/******************************************************************************
 * PUBLIC FUNCTION PROTOTYPES
 ******************************************************************************/

bool ubus_register_forwarder(struct ubus_context *ctx, const char *path);
void ubus_broadcast_event(struct ubus_context *ctx, const char *event);

/******************************************************************************
 * END OF HEADER'S CODE
 ******************************************************************************/

#ifdef __cplusplus
}
#endif

#endif // __UBUS_H_

/** @}*/
