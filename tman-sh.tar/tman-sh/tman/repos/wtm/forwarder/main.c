/**
 * wtm-forwarder - Reverse proxy between local and remote endpoints
 *
 * Copyright (C), 2023, Wimark Systems, LLC ("Wimark").
 * All Rights Reserved.
 *
 * This software contains the intellectual property of Wimark
 * or is licensed to Wimark from third parties. Use of this
 * software and the intellectual property contained therein is expressly
 * limited to the terms and conditions of the License Agreement under which
 * it is provided by Wimark.
 *
 */

#include <libubox/uloop.h>
#include <libubus.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "forwarder.h"
#include "ubus.h"

#define BROADCAST_NAME_LEN 512

#define NODAEMONIZE_ENV "WTM_NODAEMONIZE"

#define LOCAL_DOWN_EV_FMT  "%s.local_down"
#define REMOTE_DOWN_EV_FMT "%s.remote_down"
#define UP_EV_FMT          "%s.up"
#define DOWN_EV_FMT        "%s.shutdown"

static char down_broadcast[BROADCAST_EVENT_SIZE];

static void daemonize(void);
static void setup_down_cb(const struct forwarder_config * conf, void (*cb)());
static void broadcast_down_event(void);

int main(int argc, char * argv[])
{

    if (argc < 6)
    {
        printf("Usage: %s "
               "LOCAL_HOST LOCAL_PORT "
               "REMOTE_HOST REMOTE_PORT "
               "INSTANCE_NAME\n",
               argv[0]);
        exit(EXIT_FAILURE);
    }

    struct forwarder_config conf;
    memset(&conf, 0, sizeof(conf));

    conf.local_host  = argv[1];
    conf.local_port  = argv[2];
    conf.remote_host = argv[3];
    conf.remote_port = argv[4];
    conf.instance    = argv[5];

    int n = 0;

    n = snprintf(conf.ulocal.ubus_broadcast, BROADCAST_EVENT_SIZE, LOCAL_DOWN_EV_FMT, conf.instance);

    if (n >= BROADCAST_EVENT_SIZE)
    {
        fprintf(stderr, "Local down event name is too long\n");
        exit(EXIT_FAILURE);
    }

    n = snprintf(conf.uremote.ubus_broadcast, BROADCAST_EVENT_SIZE, REMOTE_DOWN_EV_FMT, conf.instance);

    if (n >= BROADCAST_EVENT_SIZE)
    {
        fprintf(stderr, "Remote down event name is too long\n");
        exit(EXIT_FAILURE);
    }

    n = snprintf(conf.up_broadcast, BROADCAST_EVENT_SIZE, UP_EV_FMT, conf.instance);

    if (n >= BROADCAST_EVENT_SIZE)
    {
        fprintf(stderr, "Up event name is too long\n");
        exit(EXIT_FAILURE);
    }

    n = snprintf(conf.down_broadcast, BROADCAST_EVENT_SIZE, DOWN_EV_FMT, conf.instance);

    if (n >= BROADCAST_EVENT_SIZE)
    {
        fprintf(stderr, "Down event name is too long\n");
        exit(EXIT_FAILURE);
    }

    printf("Started new wtm-forwarder instance: %s\n", conf.instance);

    int err = ubus_connect_ctx(&conf.context, NULL);
    if (err)
    {
        fprintf(stderr, "Failed to create ubus connection: %s\n", ubus_strerror(err));
        exit(EXIT_FAILURE);
    }

    uloop_init();
    ubus_add_uloop(&conf.context);

    if (!ubus_register_forwarder(&conf.context, conf.instance))
    {
        exit(EXIT_FAILURE);
    }

    if (!setup_forwarder(&conf))
    {
        exit(EXIT_FAILURE);
    }

    const char * nodaemonize = getenv(NODAEMONIZE_ENV);
    if (!nodaemonize || strcmp(nodaemonize, "1"))
    {
        daemonize();
    }

    setup_down_cb(&conf, broadcast_down_event);

    uloop_run();
    uloop_done();
}

static void daemonize(void)
{
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("Failed to daemonize");
        exit(EXIT_FAILURE);
    }

    if (pid > 0)
    {
        exit(EXIT_SUCCESS);
    }

    umask(0);
    setsid();

    // No need to close stin/stdout descriptors, as they provide useful info
}

static void setup_down_cb(const struct forwarder_config * conf, void (*cb)())
{
    memcpy(down_broadcast, conf->down_broadcast, BROADCAST_EVENT_SIZE);
    atexit(broadcast_down_event);

    for (int i = 1; i < _NSIG; ++i)
    {
        signal(i, cb);
    }
}

static void broadcast_down_event(void)
{
    struct ubus_context ctx = {0};

    int err = ubus_connect_ctx(&ctx, NULL);
    if (err)
    {
        fprintf(stderr,
                "Failed to create ubus connection to broadcast down "
                "event: %s\n",
                ubus_strerror(err));
        exit(EXIT_FAILURE);
    }

    ubus_broadcast_event(&ctx, down_broadcast);
}