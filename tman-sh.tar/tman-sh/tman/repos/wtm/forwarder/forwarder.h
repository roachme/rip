/**
  * @file      forwarder.h
  *
  * @brief     Setup traffic forwarder between local and remote endpoints
  *
  * @date      2023-11-22
  *
  * @par
  * Copyright (C), 2023, Wimark Systems, LLC ("Wimark").
  * All Rights Reserved.
  *
  * This software contains the intellectual property of Wimark
  * or is licensed to Wimark from third parties. Use of this
  * software and the intellectual property contained therein is expressly
  * limited to the terms and conditions of the License Agreement under which
  * it is provided by Wimark.
  *
  */

/** \addtogroup Forwarder
*  @{
*/

#ifndef __FORWARDER_H_
#define __FORWARDER_H_

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
 * INCLUDES
 ******************************************************************************/

#include <libubox/uloop.h>
#include <libubus.h>

#include "ubus.h"

/******************************************************************************
 * PUBLIC FUNCTION PROTOTYPES
 ******************************************************************************/

bool setup_forwarder(struct forwarder_config *context);

/******************************************************************************
 * END OF HEADER'S CODE
 ******************************************************************************/

#ifdef __cplusplus
}
#endif

#endif // __FORWARDER_H_

/** @}*/
