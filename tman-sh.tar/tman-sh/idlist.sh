
function idlist_sample()
{
    echo "id_prio"
}
