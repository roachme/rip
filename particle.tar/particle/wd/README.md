***wd***<br/>
wd stnds for warp directory. It lets you jump to custom directoriy in bash. `cd` is inefficient when the folder is frequently used or has a long path<br/>

***Build***<br/>
  * `make init`       - to make obj dir, correct ~/.bachrc
  * `make`            - to build prj
  * `make install`    - to install project and deps


***Examples***<br/>
  *  `wd -a code`  - make new point `code` <br>
  * `wd -l`       - show all pooints      <br>


***Requirments***<br/>
  * Linux
  * Bash (no zsh, csh)
 
 
