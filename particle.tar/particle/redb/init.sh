#!/bin/bash

sudo apt-get update
sudo apt-get install python3-pip
pip3 install vk_api
