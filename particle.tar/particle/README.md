# particle

I've a weak machine also my hhd's broken so i use live linux OS istalled in USB stick. I know there's a persistence mode i can use
and everything 'might' look ok BUT it impairs my perfornce.. that's why i wrote utils i use to make my life working on live Linux easier.
I created a separate partition where i can save my files so i won't lose 'em once i snap PC off. These utils are meant to make a believe
that use use persistence mode by saving your files on the separate partition, back up and clean cache as times, provide access to
libs and commands installed on the separate partirion and all. 

* box  - initiats your sessions, provated symlink to yer files, sets up time and many more
* nuke - formats partition reserved for data. Also can create a new live ISO image if you need updated OS
* wd   - tool that helps ya not to write exact directory over and over again. helpful when u visit the same directory often
* redb - notifier for my social media bacause system notifier on my computer sucks sometimes 
